/*==============================================================================
 *   Source code:  OutputDatesMain.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #5 Redirection and Pipes
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  12 November, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *      Using Makefile: make BuildAll
 *      Not using Makefile:
 *  gcc ValidateDatesMain.c -o ValidDates.out -std=c99
 *  gcc OutputDatesMain.c -o OutputDates.out -std=c99
 *  ./ValidDates.out < dates.dat "validEntries" | ./OutputDates.out > output.txt
 *  e.g ./ValidDates.out < dates.dat 0 | ./OutputDates.out > output.txt
 *
 *   Note:
 *   1. RedirectionHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) both programs and clean
 *   the .o files.
 *   3. "validEntries" must be an integer number greater or equal 0.
 *   4. The use of the tag -std=c99 is needed to allows the declaration of the
 *   counter variable inside for loops.
 *   5. Input redirection does not count as command line input, < dates.dat
 *   means that the input for the first program (ValidateDatesMain.c) will be
 *   coming from the file dates.dat
 *   6. Output redirection works the same, > output.txt means that the output
 *   from the second program (OutputDates.out) will be going to the file
 *   output.txt.
 *   7. The vertical line | (pipe) means that the output of the first program
 *   will be the input of the second one, therefore, both programs will be
 *   working simultaneously.
 *
 *  +---------------------------------------------------------------------------
 *
 *  Description: This assignment will use two main programs, one for read an
 *  input file of dates and the other to generate an output file that contains
 *  a list of validated and converted dates, along with the contents of the
 *  original input file. In summary, implement a pair of programs that will
 *  interface and exchange data — in this case, a list of dates - via a pipe.
 *
 *  Input: This program accept the validated dates in the month/day/year format
 *  from program ValidateDatesMain.c and convert each of them (if any) to the
 *  day, abbreviated month & year format. These dates will be coming from the
 *  first program and will already be validated; they will simply need to be
 *  converted and output.
 *
 *  Output: Generate an output file (output.txt) that  contains a list of
 *  converted dates in day, abbreviated month & year format (i.e. 1 JAN 1900),
 *  followed by the original list of dates. The abbreviated month should consist
 *  of the first three letters of the month, capitalized. These converted dates
 *  will be redirected to the output text file (e.g. output.txt). Upon
 *  completion, this output will be followed by a copy of the complete original
 *  (dates.dat) data.
 *
 *  Process:
 *  1. Accept input from program 1 (ValidateDatesMain.c) via pipe
 *  2. Converted dates in day, abbreviated month & year format (i.e. 1 JAN 1900)
 *  3. These converted dates will be redirected to the output text file
 *  (e.g. output.txt).
 *  4. Upon completion, this output will be followed by a copy of the complete
 *  original (dates.dat) data
 *
 *   Required Features Not Included:
 *              None
 *
 *   Known Bugs:
 *              None
 *============================================================================*/


#include "RedirectionHeader.h" //For shared elements.


//Useful to print the abbreviated month letters.
const char *MONTHS_OF_THE_YEAR[MONTHS_IN_A_YEAR] = {NO_VALUE, JAN_STRING,
        FEB_STRING,	MAR_STRING, APR_STRING, MAY_STRING, JUN_STRING, JUL_STRING,
        AUG_STRING, SEP_STRING, OCT_STRING, NOV_STRING, DEC_STRING};


//-- Function Prototypes --//
void acceptAndOutputDates();
void outputOriginalDates();


int main(void)
{
	acceptAndOutputDates();
	outputOriginalDates();
	
	return NO_ERROR;
}


/*---------------------------- outputOriginalDates -----------------------------
 *   Function outputOriginalDates()
 *
 *   Purpose: This function opens the file (dates.dat) that contains the
 *   original dates, (all of them) and display them at the end of and existing
 *   output.txt file (append). If the input file cannot be opened it display
 *   a corresponding message. It close the file afterwards.
 *
 *   @param  none
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void outputOriginalDates()
{
	FILE *fileReaderPtr = NULL;
	char datePtr[STRING_SIZE_MAX] = {NO_VALUE};
	if ((fileReaderPtr = fopen(INPUT_FILE, READ_MODE)) == NULL)
	{
		fprintf(stderr,"\nFile %s could not be opened\n", INPUT_FILE);
	}
	else
	{
		puts("\nOriginal dates:");
		while (fscanf(fileReaderPtr, "%s", datePtr) != EOF)
		{
			printf("%s\n", datePtr);
		}
	}
	fclose(fileReaderPtr);
}


/*---------------------------- acceptAndOutputDates ----------------------------
 *   Function acceptAndOutputDates()
 *
 *   Purpose: This function receives the validated dates produced by program 1,
 *   process them into the desired format abbreviated month & year format
 *   (i.e. 1 JAN 1900) and display it into a file (output.txt). It keeps
 *   receiving dates until it receives a specific value (SENTINEL_VALUE) and
 *   then stops.
 *
 *   @param  none
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void acceptAndOutputDates()
{
	char datePtr[STRING_SIZE_MAX] = {NO_VALUE};
	int matchedChars = NO_VALUE;
	int flag = TRUE;
	Date validatedDate = {NO_VALUE};
	char dummy = NO_VALUE;
	puts("Validated dates in the correct format:");
	while((scanf("%s", datePtr) != SENTINEL_VALUE) && (flag == TRUE))
	{
		matchedChars = sscanf(datePtr, DATE_FORMAT, &validatedDate.month,
		                      &validatedDate.day, &validatedDate.year, &dummy);
		if(matchedChars == MONTH_DAY_YEAR)
		{
			printf(OUTPUT_FORMAT, validatedDate.day,
			       MONTHS_OF_THE_YEAR[validatedDate.month],
			       (int)validatedDate.year);
		}
		else
		{
			flag = FALSE;
		}
	}
}

