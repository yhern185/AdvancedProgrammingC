/*==============================================================================
 *   Source code:  ValidateDatesMain.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #5 Redirection and Pipes
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  12 November, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *      Using Makefile: make BuildAll
 *      Not using Makefile:
 *  gcc ValidateDatesMain.c -o ValidDates.out -std=c99
 *  gcc OutputDatesMain.c -o OutputDates.out -std=c99
 *  ./ValidDates.out < dates.dat "validEntries" | ./OutputDates.out > output.txt
 *  e.g ./ValidDates.out < dates.dat 0 | ./OutputDates.out > output.txt
 *
 *   Note:
 *   1. RedirectionHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) both programs and clean
 *   the .o files.
 *   3. "validEntries" must be an integer number greater or equal 0. A zero
 *   indicates to input all valid entries from the dates input file.
 *   4. The use of the tag -std=c99 is needed to allows the declaration of the
 *   counter variable inside for loops.
 *   5. Input redirection does not count as command line input, < dates.dat
 *   means that the input for the first program (ValidateDatesMain.c) will be
 *   coming from the file dates.dat
 *   6. Output redirection works the same, > output.txt means that the output
 *   from the second program (OutputDates.out) will be going to the file
 *   output.txt.
 *   7. The vertical line | (pipe) means that the output of the first program
 *   will be the input of the second one, therefore, both programs will be
 *   working simultaneously.
 *
 *  +---------------------------------------------------------------------------
 *
 *  Description: This assignment will use two main programs, one for read an
 *  input file of dates and the other to generate an output file that contains
 *  a list of validated and converted dates, along with the contents of the
 *  original input file. In summary, implements a pair of programs that will
 *  interface and exchange data — in this case, a list of dates - via a pipe.
 *
 *  Input: This program accept input via the command-line arguments.
 *  Command-line input will be the number of valid entries (>= 0) to be
 *  redirected from the dates input file (dates.dat). A zero indicates to input
 *  all valid entries from the dates input file. The command-line input must be
 *  validated, with all error messages going to the screen, followed by
 *  graceful termination of the programs. Handles instances where the
 *  command-line input value exceeds the number of valid entries in the file.
 *  This program will validate dates only in valid month/day/year
 *  format (i.e. 1/1/1900), skipping any corrupt dates in the dates.dat file.
 *  Each date entry in the input file will terminate with a newline.
 *  A valid year is in the range [INT_MIN..INT_MAX] - negative years and year
 *  zero are valid. Valid days [1-31] varies for each month [1-12] and leap
 *  years are considered.
 *  We add a Leap Day on February 29, almost every four years. The leap day is
 *  an extra day and we add it to the shortest month of the year, February. In
 *  the Gregorian calendar three criteria must be taken into account to identify
 *  leap years:
 *  1.  The year can be evenly divided by 4;
 *  2.  If the year can be evenly divided by 100, it is NOT a leap year, unless;
 *  3.  The year is also evenly divisible by 400. Then it is a leap year.
 *  This means that in the Gregorian calendar, the years 2000 and 2400 are leap
 *  years, while 1800, 1900, 2100, 2200, 2300 and 2500 are NOT leap years. For
 *  more information please refer to:
 *  https://www.timeanddate.com/date/leapyear.html
 *  For information about redirection, please refer to:
 *  https://fsl.fmrib.ox.ac.uk/fslcourse/unix_intro/io.html
 *  The validated dates will then be piped out to the second program. It
 *  handles arithmetic overflow situations with regard to the range of a valid
 *  year.
 *  For information about piping, please refer to:
 *  https://www.geeksforgeeks.org/piping-in-unix-or-linux/
 *
 *  Output: This program output will be the input from the program number 2
 *  (OutputDates.c) via piping. It will send every required validated date from
 *  the input file (Dates.dat)
 *
 *  Process:
 *  1. Validate input from command line. Checking amount of arguments,
 *  if validEntries is an integer number between 0 and INT_MAX.
 *  2. Validate dates format. Years are in the range [INT_MIN..INT_MAX], days
 *  [1-31] varies for each month [1-12] and leap years are considered.
 *  3. Skip corrupt dates.
 *  4. Check if the number of validEntries in the command line is the same as
 *  the valid dates found in the input file (Dates.dat).
 *  5. Check for overflow cases when year would be greater than INT_MAX or less
 *  than INT_MIN.
 *  6. Send validated date to program 2 (OutputDates.c)
 *
 *   Required Features Not Included:
 *              None
 *
 *   Known Bugs:
 *              None
 *============================================================================*/


#include "RedirectionHeader.h" //For shared elements.


//-- Function Prototypes --//
int commandLineValidation(int argc, char **argsPtr);
int displayError(enum errors errors);
int checkForIntegersOnly(char **argsPtr);
int validateRange(char **argsPtr);
void validateDates(char **argsPtr);
int isCorrectYear(long int year);
int isLeapYear(int year);
int isCorrectMonth(int month);
int isCorrectDay(int day, int month, int year);


int main(int argc, char *argv[])
{
	if(commandLineValidation(argc, argv))
	{
		return ERROR;
	}
	validateDates(argv);
	
	return NO_ERROR;
}


/*---------------------------- validateDates -----------------------------------
 *   Function validateDates(char **argsPtr)
 *
 *   Purpose: This function validates a series of dates from a file dates.dat
 *   that have been redirected to be the input of this program. It receives the
 *   dates via (stdin) and makes sure is in the right format: month/day/year
 *   format (i.e. 1/1/1900), skipping any corrupt dates in the dates.dat file.
 *   Each date entry in the input file is expected to terminate with a newline.
 *   On success the function will print the date, in this case since the output
 *   of the first program is the input of the second one, that date will be pass
 *   on to the second program.
 *   Uses scanf() to save a string into an array of chars and validate the date
 *   in positive case it passes the string to the second program, skip the
 *   corrupt date otherwise.
 *
 *   @param  char **argsPtr
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void validateDates(char **argsPtr)
{
	const int VALID_ENTRIES = atoi(argsPtr[FIRST_ARG]);
	char datePtr[STRING_SIZE_MAX] = {NO_VALUE};
	Date rawDate = {NO_VALUE};
	int validDates = NO_VALUE;
	int matchedChars = NO_VALUE;
	char dummy = NO_VALUE;
	
	while((scanf("%s", datePtr) != EOF) &&
		((validDates < VALID_ENTRIES) || (VALID_ENTRIES == NO_VALUE)))
	{
		matchedChars = sscanf(datePtr, DATE_FORMAT, &rawDate.month,
				&rawDate.day, &rawDate.year, &dummy);
		if (matchedChars == MONTH_DAY_YEAR)
		{
			if ((isCorrectYear(rawDate.year)) && (isCorrectMonth(rawDate.month))
					&& (isCorrectDay(rawDate.day, rawDate.month,
							(int) rawDate.year)))
			{
				printf("%s\n", datePtr);
				validDates++;
			}
		}
	}
	printf("%d\n", SENTINEL_VALUE);
}


/*---------------------------- isCorrectDay ------------------------------------
 *   Function isCorrectDay(int day, int month, int year)
 *
 *   Purpose: This function validates that the day received in the date is in
 *   the right range, between [1-31]. It considerate months with 30, 31, and 28
 *   days, and the special case for leap years when february has 29 days.
 *
 *   @param  int day
 *   @param  int month
 *   @param  int year
 *
 *  @return  int validDay
 *----------------------------------------------------------------------------*/
int isCorrectDay(int day, int month, int year)
{
	int validDay = FALSE;
	if((month == JANUARY) || (month == MARCH) || (month == MAY) ||
		(month == JULY) || (month == AUGUST) || (month == OCTOBER) ||
			(month == DECEMBER))
	{
		if((day >= FIRST_DAY) && (day <= LAST_DAY_LONG_MONTHS))
		{
			validDay = TRUE;
		}
	}
	else if((month == APRIL) || (month == JUNE) || (month == SEPTEMBER) ||
	        (month == NOVEMBER))
	{
		if((day >= FIRST_DAY) && (day <= LAST_DAY_SHORT_MONTHS))
		{
			validDay = TRUE;
		}
	}
	else
	{
		int leapYear = isLeapYear(year);
		if(((leapYear == TRUE) && (day >= FIRST_DAY) &&
			(day <= LAST_DAY_FEBRUARY_LEAP_YEAR)) || ((leapYear == FALSE) &&
			(day >= FIRST_DAY) && (day <= LAST_DAY_FEBRUARY)))
		{
			validDay = TRUE;
		}
	}
	return validDay;
}


/*---------------------------- isCorrectMonth ----------------------------------
 *   Function isCorrectMonth(int month)
 *
 *   Purpose: This function validates that the month received in the date is in
 *   the right range, between [1-12].
 *
 *   @param  int month
 *
 *  @return  int validMonth
 *----------------------------------------------------------------------------*/
int isCorrectMonth(int month)
{
	int validMonth = FALSE;
	if((month >= FIRST_MONTH) && (month <= LAST_MONTH))
	{
		validMonth = TRUE;
	}
	return validMonth;
}


/*---------------------------- isLeapYear --------------------------------------
 *   Function isLeapYear(int year)
 *
 *   Purpose: This function determine if certain year is a leap year.
 *   We add a Leap Day on February 29, almost every four years. The leap day is
 *   an extra, day and we add it to the shortest month of the year, February. In
 *   the Gregorian calendar three criteria must be taken into account to
 *   identify leap years:
 *   1.  The year can be evenly divided by 4;
 *   2.  If the year can be evenly divided by 100, it is NOT a leap year,
 *   unless;
 *   3.  The year is also evenly divisible by 400. Then it is a leap year.
 *   This means that in the Gregorian calendar, the years 2000 and 2400 are leap
 *   years, while 1800, 1900, 2100, 2200, 2300 and 2500 are NOT leap years. For
 *   more information please refer to:
 *   https://www.timeanddate.com/date/leapyear.html
 *
 *   @param  int year
 *
 *  @return  int validLeapYear
 *----------------------------------------------------------------------------*/
int isLeapYear(int year)
{
	int validLeapYear = FALSE;
	if((year % FOUR) == NO_VALUE)
	{
		if((year % ONE_HUNDRED) != NO_VALUE)
		{
			validLeapYear = TRUE;
		}
		else
		{
			if((year % FOUR_HUNDRED) == NO_VALUE)
			{
				validLeapYear = TRUE;
			}
		}
	}
	return validLeapYear;
}


/*---------------------------- isCorrectYear -----------------------------------
 *   Function isCorrectYear(long int year)
 *
 *   Purpose: This function validates that the year received in the date is in
 *   the right range, between INT_MIN and INT_MAX by specs.
 *
 *   @param  long int year
 *
 *  @return  int validYear
 *----------------------------------------------------------------------------*/
int isCorrectYear(long int year)
{
	int validYear = FALSE;
	if((year >= INT_MIN) && (year <= INT_MAX))
	{
		validYear = TRUE;
	}
	return validYear;
}


/*---------------------------- commandLineValidation ---------------------------
 *   Function commandLineValidation(int argc, char **argsPtr)
 *
 *   Purpose: This function validates the command line input. First verify if
 *   only two parameters were received, then checks if the second parameter
 *   is an integer number greater or equal to 0. If any of these fail it calls
 *   a helper function tho inform the user what was the issue.
 *
 *   @param  int argc
 *   @param  char **argsPtr
 *
 *  @return  int errorValue
 *----------------------------------------------------------------------------*/
int commandLineValidation(int argc, char **argsPtr)
{
	int amountOfArguments = argc;
	int errorValue = NO_VALUE;
	if(amountOfArguments != EXPECTED_ARGS)
	{
		errorValue = displayError(MORE_ARGS_THAN_EXPECTED);
	}
	else if(checkForIntegersOnly(argsPtr))
	{
		errorValue = displayError(INTEGERS_ONLY);
	}
	else if(validateRange(argsPtr))
	{
		errorValue = displayError(NOT_IN_RANGE);
	}
	return errorValue;
}


/*---------------------------- displayError ------------------------------------
 *   Function displayError(enum errors errors)
 *
 *   Purpose: This function returns ERROR; to gracefully terminate the program.
 *   Accepts as parameter an specific error to be display to inform the user
 *   what was the issue the terminated the program. Use stderr to display the
 *   issue to the screen. For more info please refer to:
 *   https://www.tutorialspoint.com/cprogramming/c_error_handling.htm
 *
 *   @param  enum errors errors
 *
 *  @return  ERROR
 *----------------------------------------------------------------------------*/
int displayError(enum errors errors)
{
	if(errors == MORE_ARGS_THAN_EXPECTED)
	{
		fprintf(stderr, ERROR_FORMAT, "Only ", EXPECTED_ARGS, " arguments "
					"expected in the command line.");
	}
	else if(errors == INTEGERS_ONLY)
	{
		fprintf(stderr, ERROR_FORMAT, "Only integers numbers greater than [",
				NO_VALUE, "] in the command line.");
	}
	else
	{
		fprintf(stderr, ERROR_FORMAT, "Number of valid entries must be greater "
					 "or equal than [", NO_VALUE, "].");
	}
	return ERROR;
}


/*---------------------------- checkForIntegersOnly ----------------------------
 *   Function checkForIntegersOnly(char **argv)
 *
 *   Purpose: This function guaranties that the argument passed in the command
 *   line is an integer number. In order to do so use the function sscanf()
 *   that reads formatted input from an string and on success return the number
 *   of variables filled. In the case of an input failure before any data could
 *   be successfully read, EOF is returned. For more info please refer to:
 *   https://www.tutorialspoint.com/c_standard_library/c_function_sscanf.htm
 *   Then uses the functions atoi() that returns the converted integral number
 *   as an int value. If no valid conversion could be performed, it returns zero.
 *   And atof() that does the same but returns a floating point value. They are
 *   very useful to retrieve a value from an array of string and compare then in
 *   case of floating point input in the command line. For more information
 *   please refer to:
 *   https://www.tutorialspoint.com/c_standard_library/c_function_atoi.htm
 *   https://www.tutorialspoint.com/c_standard_library/c_function_atof.htm
 *
 *   @param  char **argsPtr
 *
 *  @return  int errorValue
 *----------------------------------------------------------------------------*/
int checkForIntegersOnly(char **argsPtr)
{
	int errorValue = NO_ERROR;
	double receivedValue = DOUBLE_INITIALIZATION;
	char dummyValue = NO_VALUE;
	int matchedInputs = sscanf(argsPtr[FIRST_ARG],"%lf %c",
		                           &receivedValue, &dummyValue);
	if(matchedInputs != NUMBERS_ONLY)
	{
		errorValue = INTEGERS_ONLY;
	}
	else
	{
		double cardsNumberDouble = atof(argsPtr[FIRST_ARG]);
		int cardsNumber = (int)cardsNumberDouble;
		if(cardsNumberDouble != cardsNumber)
		{
			errorValue = INTEGERS_ONLY;
		}
	}
	return errorValue;
}


/*---------------------------- validateRange -----------------------------------
 *   Function checkForIntegersOnly(char **argv)
 *
 *   Purpose: This function returns ERROR if the parameter passed in the command
 *   line (validEntries) is less than 0. Return NO_ERROR otherwise.
 *
 *   @param  char **argsPtr
 *
 *  @return  int errorValue
 *----------------------------------------------------------------------------*/
int validateRange(char **argsPtr)
{
	int errorValue = NO_ERROR;
	int validEntries = atoi(argsPtr[FIRST_ARG]);
	if(validEntries < NO_VALUE)
	{
		errorValue = NOT_IN_RANGE;
	}
	return errorValue;
}