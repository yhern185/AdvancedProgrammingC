/*==============================================================================
 *   Source code:  RedirectionHeader.h
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #5 Redirection and Pipes
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  12 November, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *      Using Makefile: make BuildAll
 *      Not using Makefile:
 *  gcc ValidateDatesMain.c -o ValidDates.out -std=c99
 *  gcc OutputDatesMain.c -o OutputDates.out -std=c99
 *  ./ValidDates.out < dates.dat "validEntries" | ./OutputDates.out > output.txt
 *  e.g ./ValidDates.out < dates.dat 0 | ./OutputDates.out > output.txt
 *
 *   Note:
 *   1. RedirectionHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) both programs and clean
 *   the .o files.
 *   3. "validEntries" must be an integer number greater or equal 0.
 *   4. The use of the tag -std=c99 is needed to allows the declaration of the
 *   counter variable inside for loops.
 *   5. Input redirection does not count as command line input, < dates.dat
 *   means that the input for the first program (ValidateDatesMain.c) will be
 *   coming from the file dates.dat
 *   6. Output redirection works the same, > output.txt means that the output
 *   from the second program (OutputDates.out) will be going to the file
 *   output.txt.
 *   7. The vertical line | (pipe) means that the output of the first program
 *   will be the input of the second one, therefore, both programs will be
 *   working simultaneously.
 *
 *  +-------------------------------------------------------------------------
 *  Purpose:
 *  The purpose of this header is to link the elements of the different
 *  files that will be compiled together. It is very helpful because it lets
 *  different files to communicate and share resources making code more
 *  readable and allows the use of files for specific tasks.
 *
 * +---------------------------------------------------------------------------
 *  Constants:
 *  INPUT_FILE "dates.dat" //Filename for the input file.
 *  READ_MODE "r" //Read mode to read from a file.
 *  MONTHS_IN_A_YEAR 13 //Months in a year +1 to avoid 0.
 *  SENTINEL_VALUE -1 //Distinct value to alert that the first program finished
 *      sending valid dates.
 *  FIRST_MONTH 1 //Number for the first month of the year.
 *  LAST_MONTH 12 //Number for the last month of the year.
 *  FIRST_DAY 1 //Number for the first day of the month.
 *  LAST_DAY_SHORT_MONTHS 30 //Number for the last day of the month with 30 days
 *  LAST_DAY_LONG_MONTHS 31 //Number for the last day of the month with 31 days.
 *  LAST_DAY_FEBRUARY 28 //Number for the last day of the month for february.
 *  LAST_DAY_FEBRUARY_LEAP_YEAR 29 //Number for the last day of the month for
 *      february in a leap year.
 *  EXPECTED_ARGS 2 //Expected arguments in the command line, considering that
 *      the .out from program 1 is the first input in the command line.
 *  STRING_SIZE_MAX 255 //Predefined value to storage the strings found. This is
 *      a random number because there no really a safe number to protect against
 *      buffer overflow.
 *  MONTH_DAY_YEAR 3 //Amount of parameters expected in a date format.
 *  FIRST_ARG 1 //First argument in the command line.
 *  NO_VALUE 0 //Useful for initialization.
 *  NUMBERS_ONLY 1 //Check if only number were entered in the command line input
 *  DOUBLE_INITIALIZATION 0.0 //Initialize a double number.
 *  ERROR_FORMAT "\n%s%d%s\n" //Format used to display errors to user.
 *  DATE_FORMAT "%d/%d/%ld%c" //Specified format by specs to receive the date.
 *  OUTPUT_FORMAT "%2d %3s %d\n" //Format used to display the date by specs.
 *  JAN_STRING "JAN" //Abbreviated month letters for January
 *  FEB_STRING "FEB" //Abbreviated month letters for February
 *  MAR_STRING "MAR" //Abbreviated month letters for March
 *  APR_STRING "APR" //Abbreviated month letters for April
 *  MAY_STRING "MAY" //Abbreviated month letters for May
 *  JUN_STRING "JUN" //Abbreviated month letters for June
 *  JUL_STRING "JUL" //Abbreviated month letters for July
 *  AUG_STRING "AUG" //Abbreviated month letters for August
 *  SEP_STRING "SEP" //Abbreviated month letters for September
 *  OCT_STRING "OCT" //Abbreviated month letters for October
 *  NOV_STRING "NOV" //Abbreviated month letters for November
 *  DEC_STRING "DEC" //Abbreviated month letters for December
 *
 *============================================================================*/

#include <stdio.h>
#include <stdlib.h> //For the use of atoi(), atof()
#include <limits.h> //For the use of INT_MIN and INT_MAX


//** Constants **//
#define INPUT_FILE "dates.dat"
#define READ_MODE "r"
#define MONTHS_IN_A_YEAR 13
#define SENTINEL_VALUE -1
#define FIRST_MONTH 1
#define LAST_MONTH 12
#define FIRST_DAY 1
#define LAST_DAY_SHORT_MONTHS 30
#define LAST_DAY_LONG_MONTHS 31
#define LAST_DAY_FEBRUARY 28
#define LAST_DAY_FEBRUARY_LEAP_YEAR 29
#define EXPECTED_ARGS 2
#define STRING_SIZE_MAX 255
#define MONTH_DAY_YEAR 3
#define FIRST_ARG 1
#define NO_VALUE 0
#define NUMBERS_ONLY 1
#define DOUBLE_INITIALIZATION 0.0
#define ERROR_FORMAT "\n%s%d%s\n"
#define DATE_FORMAT "%d/%d/%ld%c"
#define OUTPUT_FORMAT "%2d %3s %d\n"
#define JAN_STRING "JAN"
#define FEB_STRING "FEB"
#define MAR_STRING "MAR"
#define APR_STRING "APR"
#define MAY_STRING "MAY"
#define JUN_STRING "JUN"
#define JUL_STRING "JUL"
#define AUG_STRING "AUG"
#define SEP_STRING "SEP"
#define OCT_STRING "OCT"
#define NOV_STRING "NOV"
#define DEC_STRING "DEC"


//** Enumerations **//
enum errors //Predefined errors to prompt user
{
	NO_ERROR, ERROR, MORE_ARGS_THAN_EXPECTED, INTEGERS_ONLY, NOT_IN_RANGE
};

enum boolean //Constants used for return values
{
	FALSE, TRUE
};

enum leapYear //Numbers to define if it is a leap year
{
	FOUR = 4, ONE_HUNDRED = 100, FOUR_HUNDRED = 400
};

enum longMonths //Months with 31 days
{
	JANUARY = 1, MARCH = 3, MAY = 5, JULY = 7, AUGUST = 8, OCTOBER = 10,
	DECEMBER = 12
};

enum shortMonths //Months with 30 days
{
	APRIL = 4, JUNE = 6, SEPTEMBER = 9, NOVEMBER = 11
};


//** Date Structure **//
struct date
{
	int day;
	int month;
	long int year;
};
typedef struct date Date;