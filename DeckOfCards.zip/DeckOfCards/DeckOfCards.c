/*==============================================================================
 *   Source code:  DeckOfCards.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #3 Deck of Cards
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  15 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *      Using Makefile: $ make build clean (compiles and clean only)
 *      Not using Makefile:
 *  gcc CardsMain.c DeckOfCards.c CardsDisplayFile.c -o Cards.out -std=c99
 *  ./Cards.out "Number of Cards" "Numbers of Players"
 *
 *   Note:
 *   1. CardsHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) the program and clean the
 *   .o files afterwards.
 *   3. "Number of Cards" and "Numbers of Players" are integer numbers to be
 *   passed in the command line, they need to be in the range [1-13] and the
 *   product of them can't be greater than 52.
 *   4. The use of the tag -std=c99 is needed in order to display the symbols
 *   for the suits and allows the declaration of the counter variable inside
 *   for loops.
 *
 *  +---------------------------------------------------------------------------
 *  Purpose:
 *  This file takes care of the process that creates the deck of cards in
 *  an ordered way, then simulates the shuffle of the cards and later deals
 *  cards to players. Everything related with the handling of the cards.
 *
 *============================================================================*/

#include "CardsHeader.h"//For shared elements.


//-- Function prototypes listed on CardsHeader.h --//


/*---------------------------- createOriginalDeck ------------------------------
 *   Function createOriginalDeck(int *originalDeck)
 *
 *   Purpose: This function fills an array of size 52 with integers in
 *   increasing order. Later on this numbers will translate into cards of a deck.
 *
 *   @param  *cleanDeck
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void createOriginalDeck(int *cleanDeck)
{
	for(int deckCounter = NO_VALUE; deckCounter < MAX_AMOUNT_OF_CARDS;
		deckCounter++)
	{
		cleanDeck[deckCounter] = deckCounter;
	}
}


/*---------------------------- shuffleDeck -------------------------------------
 *   Function shuffleDeck(int *originalDeck)
 *
 *   Purpose: This function simulates the shuffling of a deck of cards by
 *   randomly swapping the numbers inside the array. Use some ideas from the
 *   Fisher and Yates' method and from its modern implementation in the
 *   Sattolo's algorithm. For more information refer to:
 *https://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle#The_modern_algorithm
 *   The algorithm iterates throughout an array using two indexes and then swap
 *   those numbers. The first number is the counter of the for loop from first
 *   to last element while the second index is a random number for the purpose
 *   of the shuffling. To generate random numbers we use the function rand()
 *   that returns a pseudo-random number in the range of 0 to RAND_MAX.
 *   RAND_MAX is a constant whose default value may vary between implementations
 *   but it is granted to be at least 32767. We find the remainder of rand() and
 *   52 to set the number in the range we are working [0-51].
 *   For more information please refer to:
 *   https://www.tutorialspoint.com/c_standard_library/c_function_rand.htm
 *   To assure the random number is in range we find the remainder of the number
 *   with 52.
 *
 *   @param  *originalDeck
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void shuffleDeck(int *originalDeck)
{
	int randomIndex = NO_VALUE;
	int swapValue = NO_VALUE;
	for(int deckCounter = NO_VALUE; deckCounter < MAX_AMOUNT_OF_CARDS;
		deckCounter++)
	{
		randomIndex = rand() % MAX_AMOUNT_OF_CARDS;
		swapValue = originalDeck[deckCounter];
		originalDeck[deckCounter] = originalDeck[randomIndex];
		originalDeck[randomIndex] = swapValue;
	}
}


/*---------------------------- dealCardsToPlayers ------------------------------
 *   Function (const int *DECK_OF_CARDS,
 *		int playersCards[MAX_PLAYERS][MAX_CARDS], int cards, int players)
 *
 *   Purpose: This function takes the cards (non-ordered numbers) from the top
 *   of a shuffled deck of cards, where the top means the card in index 0 and
 *   then save them into a 2-dimensional array that simulates the hands of each
 *   player.
 *
 *   @param  *DECK_OF_CARDS
 *   @param  playersCards[MAX_PLAYERS][MAX_CARDS]
 *   @param  cards
 *   @param  players
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void dealCardsToPlayers(const int *DECK_OF_CARDS,
		int playersCards[MAX_PLAYERS][MAX_CARDS], int cards, int players)
{
	int deckCounter = NO_VALUE;
	for(int playersCounter = NO_VALUE; playersCounter < players;
		playersCounter++)
	{
		for(int cardsCounter = NO_VALUE; cardsCounter < cards;
			cardsCounter++)
		{
			playersCards[playersCounter][cardsCounter] =
					DECK_OF_CARDS[deckCounter];
			deckCounter++;
		}
	}
}

