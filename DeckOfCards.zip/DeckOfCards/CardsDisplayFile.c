/*==============================================================================
 *   Source code:  CardsDisplayFile.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #3 Deck of Cards
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  15 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *      Using Makefile: $ make build clean (compiles and clean only)
 *      Not using Makefile:
 *  gcc CardsMain.c DeckOfCards.c CardsDisplayFile.c -o Cards.out -std=c99
 *  ./Cards.out "Number of Cards" "Numbers of Players"
 *
 *   Note:
 *   1. CardsHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) the program and clean the
 *   .o files afterwards.
 *   3. "Number of Cards" and "Numbers of Players" are integer numbers to be
 *   passed in the command line, they need to be in the range [1-13] and the
 *   product of them can't be greater than 52.
 *   4. The use of the tag -std=c99 is needed in order to display the symbols
 *   for the suits and allows the declaration of the counter variable inside
 *   for loops.
 *
 *  +---------------------------------------------------------------------------
 *  Purpose:
 *  This file takes care of the process of the output, it handles
 *  everything related with messages to the console as well as the display of
 *  the cards from the ordered and shuffled decks, and the hands of every player.
 *
 *  Note: The declaration of const char *suits[SUITS_AMOUNT] and
 *  const char ranks[RANKS_AMOUNT] as global for the use of the file in order to
 *  be easily accessible within the file.
 *
 *============================================================================*/

#include "CardsHeader.h"//For shared elements

const char *SUITS[SUITS_AMOUNT] = {HEARTS_SYMBOL, DIAMONDS_SYMBOL, CLUBS_SYMBOL,
							   SPADES_SYMBOL};
const char RANKS[RANKS_AMOUNT] = {ACE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT,
				  NINE, TEN, JACK, QUEEN, KING};


//-- Function prototypes listed on CardsHeader.h --//


/*---------------------------- displayErrorMessage -----------------------------
 *   Function displayErrorMessage(int error)
 *
 *   Purpose: Display a specific error message depending on the user input. At
 *      the end returns ERROR with is no more than a constant equal to 1,
 *      indicating that the program terminated by some error.
 *
 *   @param  error
 *
 *  @return  ERROR
 *----------------------------------------------------------------------------*/
int displayErrorMessage(int error)
{
	if(error == NOT_THREE_ARGS)
	{
		puts("Wrong number of arguments!!! Two integer numbers are "
	   "needed.");
	}
	else if(error == INTEGERS_ONLY)
	{
		printf("Please enter only integer numbers between"
		       " [%d-%d] in the command line input.\n", MIN_CARDS,
		       MAX_CARDS);
	}
	else if(error == CARDS_NOT_IN_RANGE)
	{
		printf("Number of cards must be an integer number between"
		       " [%d-%d] in the command line input.\n", MIN_CARDS,
		       MAX_CARDS);
	}
	else if(error == PLAYERS_NOT_IN_RANGE)
	{
		printf("Number of players must be an integer number between"
		       " [%d-%d] in the command line input.\n", MIN_PLAYERS,
		       MAX_PLAYERS);
	}
	else
	{
		printf("The maximum amount of cards in a deck is %d.\n"
		"Therefore, the multiplication of the number of cards and "
		"the number of players can not be greater than %d\n",
		MAX_AMOUNT_OF_CARDS, MAX_AMOUNT_OF_CARDS);
	}
	return ERROR;
}

/*---------------------------- displayLegend -----------------------------------
 *   Function displayLegend()
 *
 *   Purpose: Display the specific legend of how the decks will be displayed.
 *
 *   @param  none
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayLegend()
{
	puts("\nThe legend is as follows:");
	printf(SUITS_DISPLAY_FORMAT, "Suits: ", "Hearts = ", HEARTS_SYMBOL,
		", Diamonds = ", DIAMONDS_SYMBOL, ", Clubs = ", CLUBS_SYMBOL,
		", and Spades = ", SPADES_SYMBOL);
	printf(RANKS_DISPLAY_FORMAT, "Ranks: ", "Ace = ", ACE, ", Two = ", TWO,
		",...", ", Ten = ", TEN, ", Jack = ", JACK,	", Queen = ", 
		QUEEN,", and King = ", KING);
}


/*---------------------------- printDeck ---------------------------------------
 *   Function printDeck(const int *DECK, int specificDeck)
 *
 *   Purpose: Prints a deck of cards using 2 for loops, first going by its suits
 *   and then by its ranks. Some ideas from:
 *   https://www.dreamincode.net/forums/topic/202808-creating-a-card-deck-in-c/
 *   were useful and it uses 2 array of chars where all the values of suits and
 *   ranks are stored form enumeration types to avoid magic numbers and
 *   increase readability.
 *   For the display of the symbols uses som UTF-8 encoding where:
 *   ♠ = U+2660 = "\xE2\x99\xA0" = "\u2660".
 *   ♣ = U+2663 = "\xE2\x99\xA3" = "\u2663".
 *   ♥ = U+2665 = "\xE2\x99\xA5" = "\u2665".
 *   ♦ = U+2666 = "\xE2\x99\xA6" = "\u2666".
 *	 For more information about the symbols please refer to:
 *   https://stackoverflow.com/questions/27133508
 *
 *   @param  *DECK
 *   @param  specificDeck
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void printDeck(const int *DECK, int specificDeck)
{
	if(specificDeck == ORDERED_DECK)
	{
		puts("\nOriginal Ordered Deck:");
	}
	else
	{
		puts("\nRandom Shuffled Deck:");
	}
	int suitValue = NO_VALUE;
	int rankValue = NO_VALUE;
	int deckCounter = NO_VALUE;
	for(int suitsCounter = NO_VALUE; suitsCounter < SUITS_AMOUNT;
		suitsCounter++)
	{
		for(int ranksCounter = NO_VALUE; ranksCounter < RANKS_AMOUNT;
			ranksCounter++)
		{
			suitValue = DECK[deckCounter] / MAX_CARDS;
			rankValue = DECK[deckCounter] % MAX_CARDS;
			printf(CARD_DISPLAY_FORMAT, RANKS[rankValue],
					SUITS[suitValue]);
			deckCounter++;
		}
		printf(NEWLINE);
	}
}

/*---------------------------- displayPlayerHands ------------------------------
 *   Function displayPlayerHands(int player_Cards[MAX_PLAYERS][MAX_CARDS],
 *		int cards, int players)
 *
 *   Purpose: This function displays in a clean, clear and aligned way the hands
 *   of every player. Use 2 for loops to iterate throughout a 2-dimension array
 *   where the cards are stored.
 *
 *   @param  player_Cards[MAX_PLAYERS][MAX_CARDS]
 *   @param  cards
 *   @param  players
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayPlayerHands(int player_Cards[MAX_PLAYERS][MAX_CARDS],
		int cards, int players)
{
	printf("\nPlayer Hands: (dealt from top/front of deck)\n");
	int suitValue = NO_VALUE;
	int rankValue = NO_VALUE;
	int deckCounter = NO_VALUE;
	int displayPlayers = STARTING_AT_ONE;
	int cardValue = NO_VALUE;
	for(int playersCounter = NO_VALUE; playersCounter < players;
		playersCounter++)
	{
		printf(PLAYER_DISPLAY_FORMAT, displayPlayers);
		displayPlayers++;
		for(int cardsCounter = NO_VALUE; cardsCounter < cards;
			cardsCounter++)
		{
			cardValue = player_Cards[playersCounter][cardsCounter];
			suitValue = cardValue / MAX_CARDS;
			rankValue = cardValue % MAX_CARDS;
			printf(CARD_DISPLAY_FORMAT, RANKS[rankValue],
					SUITS[suitValue]);
			deckCounter++;
		}
		printf(NEWLINE);
	}
}

