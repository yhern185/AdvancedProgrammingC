/*==============================================================================
 *   Source code:  CardsMain.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #3 Deck of Cards
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  15 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *      Using Makefile: $ make build clean (compiles and clean only)
 *      Not using Makefile:
 *  gcc CardsMain.c DeckOfCards.c CardsDisplayFile.c -o Cards.out -std=c99
 *  ./Cards.out "Number of Cards" "Numbers of Players"
 *
 *   Note:
 *   1. CardsHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) the program and clean the
 *   .o files afterwards.
 *   3. "Number of Cards" and "Numbers of Players" are integer numbers to be
 *   passed in the command line, they need to be in the range [1-13] and the
 *   product of them can't be greater than 52.
 *   4. The use of the tag -std=c99 is needed in order to display the symbols
 *   for the suits and allows the declaration of the counter variable inside
 *   for loops.
 *
 *  +---------------------------------------------------------------------------
 *
 *  Description: Program simulates a deck of cards and deal hands of cards.
 *      Conventional deck of cards has 52 cards: 13 ranks and 4 suits. The
 *      legend is as follows:
 *      Suits:	Hearts = '♥', Diamonds = '♦', Clubs = '♣', and Spades = '♠'
 *      Ranks:	Ace='A', Two='2',..., Ten='T', Jack='J', Queen='Q', and King='K'
 *      Simulation is able to create a deck of cards, display the original deck,
 *      shuffle the deck, display the shuffled deck, deal (from the top of the
 *      deck) the specified number of cards to the specified number of players
 *      (as per the command-line) and display each of the hands of cards. As per
 *      requirements, hands should be separate entities from the deck; Three
 *      source code files, one for main(), one the handle the deck of cards and
 *      another to take care of the output and display messages. The use of a
 *      proper user-defined header file is useful in order to shared elements
 *      between files. Use of a Makefile is required and used to easily compile
 *      and clean the .o files, Makefile will only compile and clean, not
 *      execute.
 *
 *  Input: Accept input via the command-line arguments only. Fully validate
 *      command-line input. Input will specify the # of cards/hand and the # of
 *      hands (players), in that order. Input will accept [1-13] players and
 *      from [1-13] cards per hand, keeping in mind that there are only 52 cards
 *      to deal.
 *
 *  Output: Display a legend for ranks and suits. Display the original deck
 *      (ordered) and the shuffled deck (random), and display each of the
 *      player’s hands of cards. Decks, hands and cards should be clean, clear,
 *      aligned, appropriately labeled, and easy to read. Symbols (♥ ♦ ♣ ♠)for
 *      suits are use because are attractive.
 *      For the display of the symbols uses som UTF-8 encoding where:
 *      ♠ = U+2660 = "\xE2\x99\xA0" = "\u2660".
 *	    ♣ = U+2663 = "\xE2\x99\xA3" = "\u2663".
 *	    ♥ = U+2665 = "\xE2\x99\xA5" = "\u2665".
 *	    ♦ = U+2666 = "\xE2\x99\xA6" = "\u2666".
 *	    For more information about the symbols please refer to:
 *      https://stackoverflow.com/questions/27133508
 *
 *  Process:
 *      1. Validate input in the command line checking if the amount of arguments
 *      is exactly 3, if there are just number (and nothing else follows), is
 *      any floating point value, if amount of cards and amount of players is in
 *      range [1-13] and if the amount of cards multiplied by the number of
 *      players it is not greater than the maximum amount of cards in a deck
 *      (52).
 *      2. Store numbers of cards and numbers of player found in the command
 *      line input in two variables of integer type.
 *      3. Display legend of cards.
 *      4. Create original deck of cards.
 *      5. Display original ordered deck of cards in a clean fashion way so the
 *      program will show the deck is ordered initially.
 *      6. Seed the random number generator with srand(), runs only once in the
 *      main. It decides where to start generating numbers. Otherwise, rand()
 *      will generate the same sequence every time. For more information please
 *      refer to:
 *      https://www.tutorialspoint.com/c_standard_library/c_function_srand.htm
 *      7. Shuffle deck of original ordered cards using rand() function and the
 *      ideas from Fisher, Yates and Sattolos algorithm to swap numbers inside
 *      the array simulating shuffling.
 *      8. Deal cards to players from the top of the deck (the top of the deck
 *      it is the first position of the deck of cards).
 *      9. Display cards from players.
 *      10. Create Makefile per requirements in order to compile and clean the
 *      program.
 *
 *   Required Features Not Included:
 *              None
 *
 *   Known Bugs:
 *              None
 *============================================================================*/

#include "CardsHeader.h" //For shared elements.


//-- Function Prototypes --//
int validateInput(int argc, char **argv);
int checkForIntegersOnly(char **argv);


int main(int argc, char *argv[])
{
	int deckOfCards[MAX_AMOUNT_OF_CARDS] = {NO_VALUE};
	int playersCards[MAX_PLAYERS][MAX_CARDS] = {NO_VALUE};
	if(validateInput(argc, argv))
	{
		return ERROR;
	}
	const int NUMBER_OF_CARDS = atoi(argv[FIRST_ARG]);
	const int NUMBER_OF_PLAYERS = atoi(argv[SECOND_ARG]);
	displayLegend();
	createOriginalDeck(deckOfCards);
	printDeck(deckOfCards, ORDERED_DECK);
	srand(time(NULL));
	shuffleDeck(deckOfCards);
	printDeck(deckOfCards, SHUFFLED_DECK);
	dealCardsToPlayers(deckOfCards, playersCards, NUMBER_OF_CARDS,
			NUMBER_OF_PLAYERS);
	displayPlayerHands(playersCards, NUMBER_OF_CARDS, NUMBER_OF_PLAYERS);
	
	return NO_ERROR;
}


/*---------------------------- validateInput -----------------------------------
 *   Function validateInput(int argc, char **argv)
 *
 *   Purpose: Validate the user input in order to obtain two integer values
 *   between [1-15], inclusive. These numbers will represent the number of
 *   cards and the number of players respectively. We use the value from
 *   argc (for argument count) which hold the number of command line
 *   arguments the program was invoked with. The arguments will be save in
 *   *argv (for argument vector) is a pointer to an array of strings
 *   that contains the arguments one per string. First the function makes sure
 *   that the amount or arguments is exactly 3. Then call a helper function to
 *   make sure that the arguments passed in the command line are integer numbers.
 *   Then validates the range of cards and players and last checks that the
 *   multiplication between players and cards it is not greater than 52. For
 *   more information about argc and argv please refer to:
 *   https://www.tutorialspoint.com/cprogramming/c_command_line_arguments.htm
 *
 *   @param  argc
 *   @param  **argv
 *
 *  @return  errorValue
 *----------------------------------------------------------------------------*/
int validateInput(int argc, char **argv)
{
	int errorValue = NO_ERROR;
	if(argc != NUMBER_OF_ARGS)
	{
		errorValue = displayErrorMessage(NOT_THREE_ARGS);
	}
	else if(checkForIntegersOnly(argv))
	{
		errorValue = ERROR;
	}
	else
	{
		int cardsNumber = atoi(argv[FIRST_ARG]);
		int playersNumber = atoi(argv[SECOND_ARG]);
		if((cardsNumber < MIN_CARDS) || (cardsNumber > MAX_CARDS))
		{
			errorValue = displayErrorMessage(CARDS_NOT_IN_RANGE);
		}
		else if((playersNumber < MIN_PLAYERS) ||
				(playersNumber > MAX_PLAYERS))
		{
			errorValue = displayErrorMessage(PLAYERS_NOT_IN_RANGE);
		}
		else if((cardsNumber * playersNumber) > MAX_AMOUNT_OF_CARDS)
		{
			errorValue =
					displayErrorMessage(INVALID_AMOUNT_OF_CARDS);
		}
	}
	return errorValue;
}

/*---------------------------- checkForIntegersOnly ----------------------------
 *   Function checkForIntegersOnly(char **argv)
 *
 *   Purpose: This function guaranties that the arguments passed in the command
 *   line are integer numbers only . In order to do so use the function sscanf()
 *   that reads formatted input from an string and on success return the number
 *   of variables filled. In the case of an input failure before any data could
 *   be successfully read, EOF is returned. For more info please refer to:
 *   https://www.tutorialspoint.com/c_standard_library/c_function_sscanf.htm
 *   Then uses the functions atoi() that returns the converted integral number
 *   as an int value. If no valid conversion could be performed, it returns zero.
 *   And atof() that does the same but returns a floating point value. They are
 *   very useful to retrieve a value from an array of string and compare then in
 *   case of floating point input in the command line. For more information
 *   please refer to:
 *   https://www.tutorialspoint.com/c_standard_library/c_function_atoi.htm
 *   https://www.tutorialspoint.com/c_standard_library/c_function_atof.htm
 *
 *   @param  **argv
 *
 *  @return  errorValue
 *----------------------------------------------------------------------------*/
int checkForIntegersOnly(char **argv)
{
	int errorValue = NO_ERROR;
	double receivedValue = DOUBLE_INITIALIZATION;
	char dummyValue = NO_VALUE;
	for(int argsCounter = STARTING_AT_ONE; argsCounter < NUMBER_OF_ARGS;
	    argsCounter++)
	{
		int matchedInputs = sscanf(argv[argsCounter],"%lf %c",
		                           &receivedValue, &dummyValue);
		if(matchedInputs != NUMBERS_ONLY)
		{
			return errorValue = displayErrorMessage(INTEGERS_ONLY);
		}
		else
		{
			double cardsNumberDouble = atof(argv[FIRST_ARG]);
			double playersNumberDouble = atof(argv[SECOND_ARG]);
			int cardsNumber = (int)cardsNumberDouble;
			int playersNumber = (int)playersNumberDouble;
			if((cardsNumberDouble != cardsNumber) ||
			   (playersNumberDouble != playersNumber))
			{
				return errorValue =
						displayErrorMessage(INTEGERS_ONLY);
			}
		}
	}
	return errorValue;
}


