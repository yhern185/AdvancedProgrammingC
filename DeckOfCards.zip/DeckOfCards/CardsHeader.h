/*==============================================================================
 *   Source code:  CardsHeader.h
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #3 Deck of Cards
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  15 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *      Using Makefile: $ make build clean (compiles and clean only)
 *      Not using Makefile:
 *  gcc CardsMain.c DeckOfCards.c CardsDisplayFile.c -o Cards.out -std=c99
 *  ./Cards.out "Number of Cards" "Numbers of Players"
 *
 *   Note:
 *   1. CardsHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) the program and clean the
 *   .o files afterwards.
 *   3. "Number of Cards" and "Numbers of Players" are integer numbers to be
 *   passed in the command line, they need to be in the range [1-13] and the
 *   product of them can't be greater than 52.
 *   4. The use of the tag -std=c99 is needed in order to display the symbols
 *   for the suits and allows the declaration of the counter variable inside
 *   for loops.
 *
 *  +---------------------------------------------------------------------------
 *  Purpose:
 *  The purpose of this header is to link the elements of the different
 *  files that will be compiled together. It is very helpful because it lets
 *  different files to communicate and share resources making code more
 *  readable and allows the use of files for specific tasks.
 *
 *============================================================================*/

#include <stdio.h>
#include <stdlib.h> //For the use of atoi(), atof(), rand() and srand().
#include <time.h>   //Contains prototype for function time.

//-- Constants --//
#define NUMBERS_ONLY 1
#define DOUBLE_INITIALIZATION 0.0
#define STARTING_AT_ONE 1
#define ORDERED_DECK 1
#define SHUFFLED_DECK 2
#define MAX_AMOUNT_OF_CARDS 52
#define MIN_CARDS 1
#define MAX_CARDS 13
#define MIN_PLAYERS 1
#define MAX_PLAYERS 13
#define NO_VALUE 0
#define NUMBER_OF_ARGS 3
#define FIRST_ARG 1
#define SECOND_ARG 2
#define SUITS_AMOUNT 4
#define RANKS_AMOUNT 13
#define HEARTS_SYMBOL "\u2665"      //Encoding for the Heart symbol
#define DIAMONDS_SYMBOL "\u2666"    //Encoding for the Diamond symbol
#define CLUBS_SYMBOL "\u2663"       //Encoding for the Clubs symbol
#define SPADES_SYMBOL "\u2660"      //Encoding for the Spade symbol
#define SUITS_DISPLAY_FORMAT "\t%10s%s'%s '%s'%s '%s'%s '%s'%s '\n"
#define RANKS_DISPLAY_FORMAT "\t%10s%s'%c'%s'%c'%s%s'%c'%s'%c'%s'%c'%s'%c'\n"
#define CARD_DISPLAY_FORMAT " [ %c-%s ] "
#define PLAYER_DISPLAY_FORMAT "[Player %2d] - "
#define NEWLINE "\n"


//-- Enumeration Types --//
enum ranks
{
	ACE = 'A', TWO = '2', THREE = '3', FOUR = '4', FIVE = '5', SIX = '6',
	SEVEN = '7', EIGHT = '8', NINE = '9', TEN = 'T', JACK = 'J', QUEEN = 'Q',
	KING = 'K'
};
enum errors
{
    ERROR = 1, NO_ERROR = 0, NOT_THREE_ARGS = -1, INTEGERS_ONLY = -2,
    CARDS_NOT_IN_RANGE = -3, PLAYERS_NOT_IN_RANGE = -4,
    INVALID_AMOUNT_OF_CARDS = -5
};


//-- Function Prototypes from DeckOfCards --//
void createOriginalDeck(int *deck);
void shuffleDeck(int *originalDeck);
void dealCardsToPlayers(const int *DECK_OF_CARDS,
		int playersCards[MAX_PLAYERS][MAX_CARDS], int cards,
		int players);


//-- Function Prototypes from CardsDisplayFile --//
int displayErrorMessage(int error);
void displayLegend();
void printDeck(const int *DECK, int specificDeck);
void displayPlayerHands(int player_Cards[MAX_PLAYERS][MAX_CARDS],
		int cards, int players);
