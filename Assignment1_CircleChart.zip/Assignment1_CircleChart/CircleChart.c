/*==============================================================================
 *   Source code:  CircleChart.c
 *           Author:  Yonal Hernandez
 *     Student ID:  6178656
 *    Assignment:  Program #1 Circle Property Chart
 *
 *            Course:  COP 4338 (Advanced Programming)
 *           Section:  U04 1198
 *        Instructor:  William Feild
 *        Due Date:  17 September, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *        Language:  C
 *     Compile/Run:
 * 	            gcc CircleChart.c –o CircleChart.out
 *               ./CircleChart.out
 *  +---------------------------------------------------------------------------
 *
 *  Description:  This program accepts an user input for the integer radius step
 *       in the range [1-9], inclusive. Validate the input and prompt the user
 *       again in case the user input is out of range (for this program we
 *       assume the user will input an integer number).
 *       After that, will generate a chart “step” is the specified user input.
 *       The chart will include the radius, diameter, circumference, and area
 *       values in a single table, and radius values will range from 0 to 50
 *       (inclusive), the values will be floating point numbers, with
 *       three-decimal-place precision. Also, the table should have all column
 *       entries right-justified and each column will have a heading above the
 *       entries.
 *       In order to compute the circumference, diameter and area it uses the
 *       following formulas:
 *       Diameter = 2 x radius of circle
 *       Circumference of Circle = PI x diameter = 2 PI x radius
 *       area = PI r^2
 *       Note: For more information about the formulas, please refer to:
 *       http://www.math.com/tables/geometry/circles.htm
 *
 *        Input:  Accept user input for the integer radius step in the range
 *       [1-9], inclusive. User prompt will clearly indicate what is a valid
 *       input. Prompts for and range-validate user input: range-validate
 *       ensures input to be within above range. Validate means to re-prompt
 *       user if input is invalid and not to terminate the program.
 *
 *       Output:  Generate a chart where “step” is the specified user input.
 *       The chart will include the radius, diameter, circumference, and area
 *       values in a single table, and radius values will range from 0 to 50
 *       (inclusive), the values will be floating point numbers, with
 *       three-decimal-place precision. Also, the table should have all column
 *       entries right-justified and each column will have a heading above the
 *       entries.
 *
 *  +---------------------------------------------------------------------------
 *       Constants:
 *
 *       #define PI 3.14159265358979: Constant PI to be used in the circle
 *           formulas.
 *       #define MIN_STEP 1: Minimum step allowed by specs.
 *       #define MAX_STEP 9: Maximum step allowed by specs.
 *       #define BLANK_LINE_SPACE 10: Blank line to be print after 10
 *          consecutive rows.
 *       #define MAX_RADIUS 50: Maximum value for radius to be printed on the
 *           table.
 *       #define MULTIPLY_BY_2 2: Avoid magic number 2 when multiplying by 2.
 *       #define NO_VALUE 0: Helpful to initialize variables and to be used in
 *          the return of the main.
 *       #define HEADER_FORMAT "%10s%12s%15s%8s\n": Avoid magic numbers in order
 *          to display the header of the table and make it more readable.
 *       #define CONTENT_FORMAT "%10.3f%11.3f%12.3f%13.3f\n": Avoid magic
 *          number in order to display the content of the table and make it more
 *          readable.
 *
 *  +---------------------------------------------------------------------------
 *
 *     Process:
 *       1. Do-While loop to prompt user and validate user input while this is
 *           out of specified range [1-9].
 *       2. Print header of the table since the names and format are fixed by
 *           specs, and it will be easier to come back and update in a future.
 *       3. Display table on specified format using individual methods to
 *           calculate circumference, diameter and area of the circle
 *
 *   Required Features Not Included:
 *               None
 *
 *   Known Bugs:
 *               None
 *============================================================================*/

#include <stdio.h>

#define PI 3.14159265358979
#define MIN_STEP 1
#define MAX_STEP 9
#define BLANK_LINE_SPACE 10
#define MAX_RADIUS 50
#define MULTIPLY_BY_2 2
#define NO_VALUE 0
#define HEADER_FORMAT "%10s%12s%15s%8s\n"
#define CONTENT_FORMAT "%10.3f%11.3f%12.3f%13.3f\n"

int promptAndValidate();
void displayTable(int step);
void displayHeaderOfTable();
float getDiameter(int radius);
float getCircumference(int radius);
float getArea(int radius);
void displayContentOfTable(int radius, float diameter, float circumference, float area);

int main()
{
	int userStep = promptAndValidate();
	displayTable(userStep);
	
	return NO_VALUE;
}

/*---------------------------- displayTable ------------------------------------
 *   Function displayTable(int step)
 *
 *   Purpose:  Prints the table in a clean an organized fashion. Uses various
 *      functions for help in order to display the header of the table and to
 *      calculate the circumference, diameter and area of the circle.
 *      Use an if statement in order to determine if 10 rows have been printed,
 *      if the is true then prints a blank line.
 *
 *   @param  step
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayTable(int step)
{
	int rowCounter = NO_VALUE;
	int stepsCounter = NO_VALUE;
	displayHeaderOfTable();
	for(stepsCounter = NO_VALUE; stepsCounter <= MAX_RADIUS;
		stepsCounter += step)
	{
		float diameter = getDiameter(stepsCounter);
		float circumference = getCircumference(stepsCounter);
		float area = getArea(stepsCounter);
		displayContentOfTable(stepsCounter, diameter, circumference, area);
		rowCounter++;
		if (rowCounter == BLANK_LINE_SPACE)
		{
			rowCounter = NO_VALUE;
			puts("");
		}
	}
}

/*---------------------------- displayContentOfTable ---------------------------
 *   Function displayContentOfTable(int radius, float diameter,
 *                                  float circumference, float area)
 *
 *   Purpose:  Prints a row of the table at the time. The values will be
 *      floating point numbers, with a three-decimal-place precision. Also,
 *      the table will have all column entries right-justified and each column
 *      will have a heading above the entries. We parse the radius since it is
 *      passed as an integer number in the parameters.
 *
 *   @param  radius
 *   @param  diameter
 *   @param  circumference
 *   @param  area
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayContentOfTable(int radius, float diameter,
							float circumference, float area)
{
	printf(CONTENT_FORMAT, (float)radius, diameter,	circumference, area);
}

/*---------------------------- getArea------------------------------------------
 *   Function getArea(int radius)
 *
 *   Purpose: Compute the area of a circle using the following formula:
 *      area = PI r^2
 *      Note: For more information about the formulas, please refer to:
 *      http://www.math.com/tables/geometry/circles.htm
 *      Where the radius of the circle will be every step defined by the user,
 *      for the first iteration the result will be 0.000 since the first radius
 *      is always 0.000.
 *
 *   @param  radius
 *
 *  @return  area
 *----------------------------------------------------------------------------*/
float getArea(int radius)
{
	float area = PI * radius * radius;
	return area;
}

/*---------------------------- getCircumference---------------------------------
 *   Function getCircumference(int radius)
 *
 *   Purpose: Compute the circumference of a circle using the following formula:
 *      Circumference of Circle = PI x diameter = 2 PI x radius
 *      Note: For more information about the formulas, please refer to:
 *      http://www.math.com/tables/geometry/circles.htm
 *      Where the radius of the circle will be every step defined by the user,
 *      for the first iteration the result will be 0.000 since the first radius
 *      is always 0.000.
 *
 *   @param  radius
 *
 *  @return  circumference
 *----------------------------------------------------------------------------*/
float getCircumference(int radius)
{
	float circumference = MULTIPLY_BY_2 * PI * radius;
	return circumference;
}

/*---------------------------- getDiameter ------------------------------------
 *   Function getDiameter(int radius)
 *
 *   Purpose:  Compute the diameter of a circle using the following formula:
 *      Diameter = 2 x radius of circle.
 *      Note: For more information about the formulas, please refer to:
 *      http://www.math.com/tables/geometry/circles.htm
 *      Where the radius of the circle will be every step defined by the user,
 *      for the first iteration the result will be 0.000 since the first radius
 *      is always 0.000.
 *
 *   @param  counter
 *
 *  @return  diameter
 *----------------------------------------------------------------------------*/
float getDiameter(int radius)
{
	float diameter = MULTIPLY_BY_2 * radius;
	return diameter;
}


/*---------------------------- displayHeaderOfTable ----------------------------
 *   Function displayHeaderOfTable()
 *
 *   Purpose:  Prints header of the table since the names and format are fixed
 *      by specs, and it will be easier to come back and update in a future.
 *
 *   @param  none
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayHeaderOfTable()
{
	printf(HEADER_FORMAT, "Radius", "Diameter", "Circumference", "Area");
	printf("-------------------------------------------------\n");
}

/*---------------------------- promptAndValidate -------------------------------
 *   Function promptAndValidate()
 *
 *   Purpose:  Do-While loop to prompt user and validate user input while this
 *      is out of specified range [1-9].
 *
 *   @param  none
 *
 *  @return  userInput
 *----------------------------------------------------------------------------*/

int promptAndValidate()
{
	int userInput = NO_VALUE;
	
	do
	{
		printf("Please enter radius step. Value must be an INTEGER "
		 "number between: [%d-%d]\n", MIN_STEP, MAX_STEP);
		
		scanf("%d", &userInput);
		
	}while((userInput < MIN_STEP) || (userInput > MAX_STEP));
	
	return userInput;
}
