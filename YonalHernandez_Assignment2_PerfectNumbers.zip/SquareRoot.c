/*==============================================================================
 *   Source code:  SquareRoot.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #2 Perfect Numbers and Square Root
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  1 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *          Note: PerfectNumbersHeader.h is needed in the same folder, it
 *                contains the shared elements between files.
 * 	            gcc PerfectNumbersMain.c PerfectNumbers.c SquareRoot.c
 * 	                –o PerfectNumbers.out -lm
 *              ./PerfectNumbers.out
 *  +---------------------------------------------------------------------------
 *
 *  Description:  This program determine which of a sequence of integers between
 *      [1-100000] is a “perfect number” and then compute the square root (√) of
 *      each such perfect number.
 *      The calculation of the square root (√) will be done as the sum of an
 *      infinite series:
 *            ∞
 *      √S  = ∑  xn+1 = 1/2(xn + S/xn)
 *           n=0
 *      where x0 is the initial “guess”
 *      See https://en.wikipedia.org/wiki/Methods_of_computing_square_roots for
 *      details. Use only the Babylonian method (above) for your square root (√)
 *      , and not the C math library function. However, the C math library
 *      function will be use at the end for comparison purposes.
 *
 *  Process:
 *      The purpose of this file is to find the square root of a number without
 *      the use of the sqr function from the math.h library. It uses the
 *      babylonian method. Provides a couple helper functions to provide
 *      computed values.
 *
 *  +---------------------------------------------------------------------------
 *  Global Variables:
 *      int initialGuess = INITIAL_GUESS; // Value to be used as initial value
 *          in the babylonian method. Global to the file in order to be easy
 *          accessible within the file.
 *		int iterationsCounter = NO_VALUE; // Counts how many times were needed
 *		    to determine the square root depending on the desired accuracy by
 *		    user. Global to the file in order to be easy accessible within the
 *		    file.
 *
 *============================================================================*/

#include "PerfectNumbersHeader.h" // Shared elements

int initialGuess = INITIAL_GUESS;
int iterationsCounter = NO_VALUE;

/*---------------------------- getExpectedValue --------------------------------
 *   Function getExpectedValue(int perfectNumber)
 *
 *   Purpose: Returns the expected value for the square root of any number, uses
 *      the function sqrt from the math.h library.
 *
 *   @param  perfectNumber
 *
 *  @return  expectedValue
 *----------------------------------------------------------------------------*/
double getExpectedValue(int perfectNumber)
{
	double expectedValue = sqrt(perfectNumber);
	return expectedValue;
}

/*---------------------------- getInitialGuess ---------------------------------
 *   Function getExpectedValue(int perfectNumber)
 *
 *   Purpose: Returns a rough initial guess from where the babylonian method
 *      starts to computed the square root of a number. Some estimations could
 *      be more precise, however, it would cost more time to determine the value
 *
 *   @param  perfectNumber
 *
 *  @return  initialGuess
 *----------------------------------------------------------------------------*/
double getInitialGuess(int perfectNumber)
{
	
	while((initialGuess * initialGuess) < perfectNumber)
	{
		initialGuess++;
	}
	initialGuess--;
	return initialGuess;
}

/*---------------------------- getNumberOfIterations ---------------------------
 *   Function int getNumberOfIterations()
 *
 *   Purpose: Helper function that only returns the value of the amount of times
 *      the babylonian method needed to determined the square root of a number
 *      based on a desired accuracy.
 *
 *   @param  none
 *
 *  @return  iterationsCounter
 *----------------------------------------------------------------------------*/
int getNumberOfIterations()
{
	return iterationsCounter;
}

/*---------------------------- getComputedValue --------------------------------
 *   Function getComputedValue(int perfectNumber, double threshold)
 *
 *   Purpose: Determine the square root of a number starting by an initial guess
 *      and then using the result as the initial guess of the second iteration
 *      and so on and so forth until the difference between the last two values
 *      is less than determined threshold based on the accuracy determined by
 *      user.
 *
 *   @param  perfectNumber
 *   @param  threshold
 *
 *  @return  computedValue
 *----------------------------------------------------------------------------*/
double getComputedValue(int perfectNumber, double threshold)
{
	iterationsCounter = NO_VALUE;
	double previousValue = DOUBLE_INITIALIZATION;
	double initialGuessToDouble = (double)initialGuess;
	double computedValue = DOUBLE_INITIALIZATION;
	
	do
	{
		computedValue =
				((initialGuessToDouble + (perfectNumber / initialGuessToDouble))
				/ DIVIDE_BY_TWO);
		
		previousValue =	initialGuessToDouble;
		initialGuessToDouble = computedValue;
		iterationsCounter++;
		
	}while((fabs(computedValue - previousValue)) >= threshold);

	return computedValue;
}
