/*==============================================================================
 *   Source code:  PerfectNumbers.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #2 Perfect Numbers and Square Root
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  1 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *          Note: PerfectNumbersHeader.h is needed in the same folder, it
 *                contains the shared elements between files.
 * 	            gcc PerfectNumbersMain.c PerfectNumbers.c SquareRoot.c
 * 	                –o PerfectNumbers.out -lm
 *              ./PerfectNumbers.out
 *  +---------------------------------------------------------------------------
 *
 *  Description:  This program determine which of a sequence of integers between
 *      [1-100000] is a “perfect number” and then compute the square root (√) of
 *      each such perfect number.
 *      The calculation of the square root (√) will be done as the sum of an
 *      infinite series:
 *            ∞
 *      √S  = ∑  xn+1 = 1/2(xn + S/xn)
 *           n=0
 *      where x0 is the initial “guess”
 *      See https://en.wikipedia.org/wiki/Methods_of_computing_square_roots for
 *      details. Use only the Babylonian method (above) for your square root (√)
 *      , and not the C math library function. However, the C math library
 *      function will be use at the end for comparison purposes.
 *
 *  Input: Program will prompt the user to provide the desired decimal-place
 *      accuracy, in the range of [1-15], inclusive. User prompt clearly
 *      indicate what is a valid input. User input is validated - ensuring that
 *      the value entered is an integer in the above range.
 *
 *  Output: Output will include all of the perfect numbers between [1-100000],
 *      along with an ordered list of their factors to confirm the factors sum
 *      to the perfect number. For each perfect number, the output will also
 *      include the initial square root guess, the expected value using sqrt(),
 *      the computed value for the square root of that number, the required
 *      decimal-place accuracy (as indicated by the user), the required
 *      threshold, and the number of terms (iterations) it took to reach the
 *      required decimal-place accuracy.
 *
 *  Process:
 *      1. Prompt user explaining the purpose of the program on a clear manner.
 *      2. Accept and validate user input inside specs range: [1-15], inclusive.
 *      3. Determine delta threshold based on user input.
 *      4. Find perfect numbers between [1-100000], A perfect number is a
 *         positive integer that is the sum of its proper positive divisors
 *         excluding the number itself. Equivalently, a perfect number is a
 *         number that is half the sum of all of its positive divisors
 *         (including itself).
 *         Uses the faster Lucas-Lehmer test:
 *         Note:   The faster   Lucas-Lehmer test   is used to find primes of
 *         the form   2n-1,   all known perfect numbers can be derived from
 *         these primes using the formula   (2n - 1) × 2n - 1.
 *         It is not known if there are any odd perfect numbers (any that exist
 *         are larger than 102000).
 *         The number of   known   perfect numbers is   50
 *         (as of September, 2018),   and the largest known perfect number
 *         contains over 46 million decimal digits.
 *         For more information please refer to:
 *         https://rosettacode.org/wiki/Perfect_numbers#C
 *         http://mathforum.org/library/drmath/view/52471.html
 *     5.  Compute the square root of every perfect number using the Babylonian
 *         method:
 *                ∞
 *          √S  = ∑  xn+1 = 1/2(xn + S/xn)
 *               n=0
 *          where x0 is the initial “guess”
 *          See https://en.wikipedia.org/wiki/Methods_of_computing_square_roots
 *          for details.
 *      6.  Display results of the perfect numbers between [1-100000], along
 *      with an ordered list of their factors to confirm the factors sum to the
 *      perfect number.
 *
 *   Required Features Not Included:
 *       For perfect number 496 and a desired accuracy of 15 decimal places,
 *       program is unable to satisfy requirements on the last digit,
 *       22.271057451320090 is the lowest value achieved using the babylonian
 *       method. Therefore, it was impossible to reach the expected value:
 *       22.271057451320086
 *
 *
 *   Known Bugs:
 *               None
 *============================================================================*/

#include "PerfectNumbersHeader.h" // For shared elements

//--**Function prototypes**--//
int validateInput();
double determineDeltaThreshold(int significantPlaces);
void displayPerfectNumbers(int places, int numbers);
void displayNumberAndMultiples(int counter);


int main()
{
	int decimalPlaces = validateInput();
	findPerfectNumbers(MAX_NUMBER);
	int amountOfPerfectNumbers = getAmountOfPerfectNumbers();
	displayPerfectNumbers(decimalPlaces, amountOfPerfectNumbers);
	
	return NO_ERRORS;
}

/*---------------------------- displayPerfectNumbers ---------------------------
 *   Function displayPerfectNumbers(int places, int numbers)
 *
 *   Purpose:  This function displays the required output for every perfect
 *      number. First computes the desired threshold from where we decide
 *      where to stop when computing the square root from the babylonian method.
 *      Then it displays a simple message informing what is the worst time
 *      user will need to wait for results. After that it just displays results
 *      in a very nice fashion way making use of helper functions.
 *
 *   @param  places
 *   @param  numbers
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayPerfectNumbers(int places, int numbers)
{
	double deltaThreshold = determineDeltaThreshold(places);
	printf("This may take up to %d seconds to complete…\n\n",
			WORST_RUNNING_TIME);
	
	int counter = NO_VALUE;
	for(counter; counter < numbers; counter++)
	{
		displayNumberAndMultiples(counter);
		printf("\tInitial “guess” = %.1f\n",
		       getInitialGuess(getPerfectNumber(counter)));
		printf("\tExpected square root of %d = %.15f\n",
		       getPerfectNumber(counter),
		       getExpectedValue(getPerfectNumber(counter)));
		printf("\tComputed square root of %d = %.15f\n",
		       getPerfectNumber(counter),
		       getComputedValue(getPerfectNumber(counter), deltaThreshold));
		printf("\t\treached in %d iterations\n", getNumberOfIterations());
		printf("\t\tusing threshold of %.16f\n", deltaThreshold);
		printf("\t\tfor %d decimal-place accuracy\n\n", places);
	}
}


/*---------------------------- displayNumberAndMultiples -----------------------
 *   Function displayNumberAndMultiples(int counter)
 *
 *   Purpose:  This function displays the perfect numbers followed be its
 *      multiples because the addition of all of them will be the perfect
 *      number. Uses helper functions from PerfectNumber.c file in order to
 *      retrieve the perfect number and its multiples.
 *
 *   @param  counter
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayNumberAndMultiples(int counter)
{
	printf("\tPerfectNumber: %d = ", getPerfectNumber(counter));
	printf("%d", COMMON_MULTIPLE);
	int sum = COMMON_MULTIPLE;
	int startPoint = FIRST_PRIME;
	while(sum < getPerfectNumber(counter))
	{
		int multiple = getNextMultiple(counter, startPoint);
		printf(" + %d", multiple);
		sum += multiple;
		startPoint = multiple;
		startPoint++;
	}
	puts("");
}

/*---------------------------- determineDeltaThreshold -------------------------
 *   Function determineDeltaThreshold(int significantPlaces)
 *
 *   Purpose:  Determine the delta threshold which is no more than a number to
 *      compare when computing the square root with the infinite series in order
 *      to determine if the difference between the last two values do not affect
 *      significantly the result.
 *
 *   @param  significantPlaces
 *
 *  @return  deltaThreshold
 *----------------------------------------------------------------------------*/
double determineDeltaThreshold(int significantPlaces)
{
	significantPlaces *= TOGGLE_SIGN;
	double deltaThreshold =
			COMPARE_VALUE * (pow(BASE_10, significantPlaces));
	return deltaThreshold;
}


/*---------------------------- validateInput -----------------------------------
 *   Function validateInput()
 *
 *   Purpose: Display a quick message to the user to inform what will be
 *      required.
 *      Validate the user input in order to obtain a integer value
 *      between [1-15], inclusive. In order to do so we use a do-while loop
 *      that clearly say what is an accepted input. We use the scanf return
 *      value, to get rid of non-numerical values because on success, the
 *      function returns the number of items of the argument list successfully
 *      read. If a reading error happens or the end-of-file is reached while
 *      reading, the proper indicator is set (feof or ferror) and, if either
 *      happens before any data could be successfully read, EOF is returned.
 *      For more info, please refer to:
 *      https://www.tutorialspoint.com/c_standard_library/c_function_scanf.htm
 *      In case it reads a numerical value, its cast into an integer and then
 *      compared against the received number to eliminate the possibility of
 *      floating point values. Then it is tested against the range specified
 *      above.
 *
 *
 *   @param  none
 *
 *  @return  decimalPlaces
 *----------------------------------------------------------------------------*/
int validateInput()
{
	puts("\nPlease enter the desired decimal-place accuracy.");
	double receivedValue = DOUBLE_INITIALIZATION;
	int decimalPlaces = NO_VALUE;
	do
	{
		printf("Value must be an integer number between: [%d-%d]",
		       MIN_DECIMAL_PLACES, MAX_DECIMAL_PLACES);
		int matchedInputs = scanf("%lf", &receivedValue);
		if((matchedInputs != NO_VALUE) && (getchar() == NEWLINE_CHAR))
		{
			decimalPlaces = (int)receivedValue;
		}
		else
		{
			while(getchar() != NEWLINE_CHAR);
		}
	}
	while((decimalPlaces != receivedValue) ||
			(decimalPlaces < MIN_DECIMAL_PLACES) ||
		    (decimalPlaces > MAX_DECIMAL_PLACES));
	
	puts("");
	return decimalPlaces;
}