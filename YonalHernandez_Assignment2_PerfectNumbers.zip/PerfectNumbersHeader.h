/*==============================================================================
 *   Source code:  PerfectNumbersHeader.h
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #2 Perfect Numbers and Square Root
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  1 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *          Note: PerfectNumbersHeader.h is needed in the same folder, it
 *                contains the shared elements between files.
 * 	            gcc PerfectNumbersMain.c PerfectNumbers.c SquareRoot.c
 * 	                –o PerfectNumbers.out -lm
 *              ./PerfectNumbers.out
 *  +---------------------------------------------------------------------------
 *
 *  Description:  This program determine which of a sequence of integers between
 *      [1-100000] is a “perfect number” and then compute the square root (√) of
 *      each such perfect number.
 *      The calculation of the square root (√) will be done as the sum of an
 *      infinite series:
 *            ∞
 *      √S  = ∑  xn+1 = 1/2(xn + S/xn)
 *           n=0
 *      where x0 is the initial “guess”
 *      See https://en.wikipedia.org/wiki/Methods_of_computing_square_roots for
 *      details. Use only the Babylonian method (above) for your square root (√)
 *      , and not the C math library function. However, the C math library
 *      function will be use at the end for comparison purposes.
 *
 *  Process:
 *      The purpose of this header is to link the elements of the different
 *      files that will be compiled together. It is very helpful because it lets
 *      different files to communicate and shared resources making code more
 *      readable.
 *
 *  +---------------------------------------------------------------------------
 *  Constants:
 *      #define NO_ERRORS 0 // Return from main with no issues
 *		#define NO_VALUE 0 // Useful to initialize integers
 *		#define DOUBLE_INITIALIZATION 0.0 //Initialize floating point values
 *		#define MIN_DECIMAL_PLACES 1 // Minimum value allowed in range
 *		#define MAX_DECIMAL_PLACES 15 // Maximum value allowed in range
 *		#define BASE_10 10 // base 10 to apply power
 *		#define TOGGLE_SIGN -1 // Change sign to elevate to the power of 10
 *		#define COMPARE_VALUE 0.1 // Defines threshold comparing two
 *		    consecutively computed values for the square root
 *		#define NEWLINE_CHAR '\n' // Increase readable when comparing in code
 *		#define MULTIPLY_BY_TWO 2 // Avoid magic number when multiplying
 *		#define MAX_AMOUNT_OF_PERFECTS 50 // Maximum number of known perfect
 *		    numbers
 *		#define MIN_NUMBER 1 // Minimum number in range to search for perfect
 *		    numbers. Avoid magic number. Easy to change in a future
 *		#define MAX_NUMBER 100000 // Minimum number in range to search for
 *		    perfect numbers. Avoid magic number. Easy to change in a future
 *		#define TRUE 1 // Avoid magic number, increase readability
 *		#define FALSE 0 // Avoid magic number, increase readability
 *		#define FIRST_PRIME 2 // Initialization purposes. Avoid magic number
 *		#define COMMON_MULTIPLE 1 // Initialization purposes. Avoid magic number
 *		#define DIVIDE_BY_TWO 2 // Avoid magic number when dividing
 *		#define INITIAL_GUESS 1 // Initial point to be considered for initial
 *		    guess
 *		#define WORST_RUNNING_TIME 5 // Uses to display message to user, worst
 *		    time is an estimate from multiples tries in the computer lab.
 *============================================================================*/

#include <stdio.h>
#include <math.h> // Defines various mathematical functions such as sqrt and pow

//------**Constants**------//

#define NO_ERRORS 0
#define NO_VALUE 0
#define DOUBLE_INITIALIZATION 0.0
#define MIN_DECIMAL_PLACES 1
#define MAX_DECIMAL_PLACES 15
#define BASE_10 10
#define TOGGLE_SIGN -1
#define COMPARE_VALUE 0.1
#define NEWLINE_CHAR '\n'
#define MULTIPLY_BY_TWO 2
#define MAX_AMOUNT_OF_PERFECTS 50
#define MIN_NUMBER 1
#define MAX_NUMBER 100000
#define TRUE 1
#define FALSE 0
#define FIRST_PRIME 2
#define COMMON_MULTIPLE 1
#define DIVIDE_BY_TWO 2
#define INITIAL_GUESS 1
#define WORST_RUNNING_TIME 5

//--**Function prototypes**--//

void findPerfectNumbers(int amountOfNumbers);
int getPerfectNumber(int index);
int getAmountOfPerfectNumbers();
int getNextMultiple(int perfectNumberIndex, int testNumber);

double getExpectedValue(int perfectNumber);
double getInitialGuess(int perfectNumber);
int getNumberOfIterations();
double getComputedValue(int perfectNumber, double threshold);



