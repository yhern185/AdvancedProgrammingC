/*==============================================================================
 *   Source code:  PerfectNumbers.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #2 Perfect Numbers and Square Root
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  1 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *          Note: PerfectNumbersHeader.h is needed in the same folder, it
 *                contains the shared elements between files.
 * 	            gcc PerfectNumbersMain.c PerfectNumbers.c SquareRoot.c
 * 	                –o PerfectNumbers.out -lm
 *              ./PerfectNumbers.out
 *  +---------------------------------------------------------------------------
 *
 *  Description:  This program determine which of a sequence of integers between
 *      [1-100000] is a “perfect number” and then compute the square root (√) of
 *      each such perfect number.
 *      The calculation of the square root (√) will be done as the sum of an
 *      infinite series:
 *            ∞
 *      √S  = ∑  xn+1 = 1/2(xn + S/xn)
 *           n=0
 *      where x0 is the initial “guess”
 *      See https://en.wikipedia.org/wiki/Methods_of_computing_square_roots for
 *      details. Use only the Babylonian method (above) for your square root (√)
 *      , and not the C math library function. However, the C math library
 *      function will be use at the end for comparison purposes.
 *
 *  Process:
 *      The purpose of this file is to find the amount of perfect numbers in a
 *      determined range of numbers and save them into an array. It also
 *      provides several helper function in order to provide the perfect numbers
 *      and multiples to the main function
 *
 * +---------------------------------------------------------------------------
 *  Global Variables:
 *      int perfectNumbers[MAX_AMOUNT_OF_PERFECTS] = {NO_VALUE}; // Array of
 *          integers to stored the perfect numbers found in a determined range.
 *          Its size is 50 since that is the maximum amount of perfect numbers
 *          known. Global to the file in order to be easy accessible within the
 *          file.
 *		int amountOfPerfectNumbers = NO_VALUE; // Save the amount of perfect
 *		    numbers found in the determined range. Global to the file in order
 *		    to be easy accessible within the  file.
 *
 *
 *============================================================================*/

#include "PerfectNumbersHeader.h" // For shared elements

int perfectNumbers[MAX_AMOUNT_OF_PERFECTS] = {NO_VALUE};
int amountOfPerfectNumbers = NO_VALUE;

//--**Function prototypes**--//
int isPrime(int test);

/*---------------------------- isPrime -----------------------------------------
 *   Function isPrime()
 *
 *   Purpose: Checks a number to determine if it is prime or not. In positive
 *      cases return true, otherwise returns false. Uses a modified method from:
 *      https://www.baeldung.com/java-generate-prime-numbers
 *      Use sqrt to narrow test numbers as much as possible instead of elevate
 *      the counter to the power of 2 making our search much more efficient.
 *      Function prototype not included in header file because is to be used
 *      only by this file.
 *
 *   @param  test
 *
 *  @return  (true[1] or false[0])
 *----------------------------------------------------------------------------*/
int isPrime(int test)
{
	int counter = FIRST_PRIME;
	for(counter; (counter <= sqrt(test)); counter++)
	{
		if(test % counter == NO_VALUE)
		{
			return FALSE;
		}
	}
	return TRUE;
}


/*---------------------------- findPerfectNumbers ------------------------------
 *   Function findPerfectNumbers(int amountOfNumbers)
 *
 *   Purpose: Find the amount of perfect numbers in a determined range of
 *      numbers and save them into an array. This array have been declared
 *      global but only for the sole use of this file, therefore, the function
 *      can accessed at any given time.
 *      Note: For more information regarding the method, please refer to:
 *      http://mathforum.org/library/drmath/view/52471.html
 *
 *   @param  amountOfNumbers
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void findPerfectNumbers(int amountOfNumbers)
{
	int startingNumber = MIN_NUMBER;
	int doubleLast = MULTIPLY_BY_TWO * startingNumber;
	int sumPrevious = startingNumber + doubleLast;
	
	do
	{
		if(isPrime(sumPrevious))
		{
			perfectNumbers[amountOfPerfectNumbers] = doubleLast * sumPrevious;
			amountOfPerfectNumbers++;
			doubleLast *= MULTIPLY_BY_TWO;
			sumPrevious += doubleLast;
		}
		else
		{
			doubleLast *= MULTIPLY_BY_TWO;
			sumPrevious += doubleLast;
		}
	}while((doubleLast * sumPrevious) < amountOfNumbers);
}

/*---------------------------- getNextMultiple ---------------------------------
 *   Function getNextMultiple(int perfectNumberIndex, int testNumber)
 *
 *   Purpose: Determine the next multiple for every perfect number by comparing
 *      the difference of the reminder with 0. Returns one multiple at the time.
 *
 *   @param  perfectNumberIndex
 *   @param  testNumber
 *
 *  @return  multiple
 *----------------------------------------------------------------------------*/
int getNextMultiple(int perfectNumberIndex, int testNumber)
{
	int multiple = NO_VALUE;
	do
	{
		if((perfectNumbers[perfectNumberIndex] % testNumber) == NO_VALUE)
		{
			return multiple = testNumber;
		}
		else
		{
			testNumber++;
		}
	}while((multiple != testNumber) ||
	(testNumber <= (perfectNumbers[perfectNumberIndex] / DIVIDE_BY_TWO)));
}


/*---------------------------- getPerfectNumber --------------------------------
 *   Function getPerfectNumber(int index)
 *
 *   Purpose: Helper function that return an integer value from an array
 *      declared global for the use of this class, the array store the perfect
 *      numbers and with the required index, a specific number is returned.
 *
 *   @param  index
 *
 *  @return  perfectNumbers[index]
 *----------------------------------------------------------------------------*/
int getPerfectNumber(int index)
{
	return perfectNumbers[index];
}

/*---------------------------- getAmountOfPerfectNumbers -----------------------
 *   Function getAmountOfPerfectNumbers()
 *
 *   Purpose: Provides the amount of perfect numbers found, the variable is
 *      declared global within the file, therefore, it can be accessed at any
 *      time. This value is useful in order to know how many time a loop needs
 *      to run in order to retrieve the perfect numbers.
 *
 *   @param  none
 *
 *  @return  amountOfPerfectNumbers
 *----------------------------------------------------------------------------*/
int getAmountOfPerfectNumbers()
{
	return amountOfPerfectNumbers;
}

