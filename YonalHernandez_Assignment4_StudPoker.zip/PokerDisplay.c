/*==============================================================================
 *   Source code:  PokerDisplay.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #4 Stud Poker
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  29 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *      Using Makefile: $ make cleanAndBuild
 *      Not using Makefile:
 *  gcc PokerMain.c PokerCards.c PokerDisplay.c -o Poker.out -std=c99
 *  ./Cards.out "Number of Cards" "Numbers of Players"
 *
 *   Note:
 *   1. PokerHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) the program and clean the
 *   .o files.
 *   3. "Number of Cards" must be any positive integer number that wil be fixed
 *   to 5.
 *   4. "Numbers of Players" must be an integer numbers between [2-10].
 *   5. The use of the tag -std=c99 is needed in order to display the symbols
 *   for the suits and allows the declaration of the counter variable inside
 *   for loops.
 *
 *  +---------------------------------------------------------------------------
 *  Purpose:
 *  This file takes care of the process of the output, it handles
 *  everything related with messages to the console as well as the display of
 *  the cards from the ordered and shuffled decks, and the hands of every player.
 *
 *  Note: The declaration of: Players playersRank[MAX_PLAYERS] = {NO_VALUE}
 *  as global for the use of the file in order to be easily accessible within
 *  the file.
 *
 *============================================================================*/

#include "PokerHeader.h"//For shared elements


//-- Function Prototypes --//
void testCases(const Cards pCard[AMOUNT_OF_CARDS], int playerCounter);
void printHand(const Cards *hand, int displayCode, int playerNumber);
void displayRankedHand(int counter);
void findWinners(int players);
void displayHands(Cards *pCard, int players);
//-- Other function prototypes listed on CardsHeader.h --//


//-- Constants --//
const char *SUITS[SUITS_AMOUNT] = {HEARTS_SYMBOL, DIAMONDS_SYMBOL,
                                   CLUBS_SYMBOL, SPADES_SYMBOL};


const char RANKS[RANKS_AMOUNT] = {TWO_CHAR, THREE_CHAR, FOUR_CHAR, FIVE_CHAR,
                                  SIX_CHAR, SEVEN_CHAR, EIGHT_CHAR, NINE_CHAR,
                                  TEN_CHAR, JACK_CHAR, QUEEN_CHAR, KING_CHAR,
                                  ACE_CHAR};

const Cards HIGH_CARD_TEST[AMOUNT_OF_CARDS] =
		{TWO_NUM, DIAMONDS_NUM, THREE_NUM, CLUBS_NUM,
		 FOUR_NUM, DIAMONDS_NUM, SIX_NUM, SPADES_NUM,
		 QUEEN_VAL, HEARTS_NUM};
const Cards ONE_PAIR_TEST[AMOUNT_OF_CARDS] =
		{FOUR_NUM, HEARTS_NUM, FIVE_NUM, HEARTS_NUM,
		 FIVE_NUM, DIAMONDS_NUM, SEVEN_NUM, HEARTS_NUM,
		 TEN_VAL, SPADES_NUM};
const Cards TWO_PAIRS_TEST[AMOUNT_OF_CARDS] =
		{THREE_NUM, DIAMONDS_NUM, THREE_NUM, HEARTS_NUM,
		 TEN_VAL, CLUBS_NUM, TEN_VAL, DIAMONDS_NUM,
		 QUEEN_VAL, CLUBS_NUM};
const Cards THREE_OF_A_KIND_TEST[AMOUNT_OF_CARDS] =
		{THREE_NUM, DIAMONDS_NUM, THREE_NUM, HEARTS_NUM,
		 THREE_NUM, SPADES_NUM, TEN_VAL, DIAMONDS_NUM,
		 QUEEN_VAL, CLUBS_NUM};
const Cards STRAIGHT_TEST[AMOUNT_OF_CARDS] =
		{ACE_VAL, SPADES_NUM, TWO_NUM, DIAMONDS_NUM,
		 THREE_NUM, CLUBS_NUM, FOUR_NUM, DIAMONDS_NUM,
		 FIVE_NUM, DIAMONDS_NUM};
const Cards FLUSH_TEST[AMOUNT_OF_CARDS] =
		{TWO_NUM, CLUBS_NUM, THREE_NUM, CLUBS_NUM,
        FOUR_NUM, CLUBS_NUM, SIX_NUM, CLUBS_NUM,
        QUEEN_VAL, CLUBS_NUM};
const Cards FULL_HOUSE_TEST[AMOUNT_OF_CARDS] =
		{THREE_NUM, DIAMONDS_NUM, THREE_NUM, HEARTS_NUM,
        THREE_NUM, SPADES_NUM,TEN_VAL, DIAMONDS_NUM,
        TEN_VAL, CLUBS_NUM};
const Cards FOUR_OF_A_KIND_TEST[AMOUNT_OF_CARDS] =
		{THREE_NUM, DIAMONDS_NUM, THREE_NUM, HEARTS_NUM,
        THREE_NUM, SPADES_NUM,THREE_NUM, CLUBS_NUM,
        QUEEN_VAL, CLUBS_NUM};
const Cards STRAIGHT_FLUSH_TEST[AMOUNT_OF_CARDS] =
		 {TEN_VAL, DIAMONDS_NUM, JACK_VAL, DIAMONDS_NUM,
		QUEEN_VAL,DIAMONDS_NUM, KING_VAL, DIAMONDS_NUM,
		ACE_VAL, DIAMONDS_NUM};

const Cards *TEST_CASES_PTR[NUMBER_OF_TEST_CASES] =
		{STRAIGHT_FLUSH_TEST, FOUR_OF_A_KIND_TEST, FULL_HOUSE_TEST, FLUSH_TEST,
        STRAIGHT_TEST, THREE_OF_A_KIND_TEST, TWO_PAIRS_TEST, ONE_PAIR_TEST,
        HIGH_CARD_TEST};

//-- Global Variables --//
Players playersRank[MAX_PLAYERS] = {NO_VALUE};


/*---------------------------- displayErrorMessage -----------------------------
 *   Function displayErrorMessage(int error)
 *
 *   Purpose: Display a specific error message depending on the user input. At
 *      the end returns ERROR with is no more than a constant equal to 1,
 *      indicating that the program terminated by some error.
 *
 *   @param  int error
 *
 *  @return  ERROR
 *----------------------------------------------------------------------------*/
int displayErrorMessage(int error)
{
	if(error == NOT_THREE_ARGS)
	{
		puts("Wrong number of arguments!!! Two integer numbers are "
	   "needed.");
	}
	else if(error == INTEGERS_ONLY)
	{
		printf("Please enter only integer numbers: \n"
		 "A positive integer number for the number of cards.\n"
		 "An integer number between [%d-%d] for number of players.",
		 MIN_PLAYERS, MAX_PLAYERS);
	}
	else if(error == CARDS_NOT_IN_RANGE)
	{
		printf("Number of cards must be a positive integer number that "
		 "will be fixed to the number: [%d].\n", AMOUNT_OF_CARDS);
	}
	else if(error == PLAYERS_NOT_IN_RANGE)
	{
		printf("Number of players must be an integer number that between"
		       " [%d-%d] in the command line input.\n", MIN_PLAYERS,
		       MAX_PLAYERS);
	}
	return ERROR;
}

/*---------------------------- displayLegend -----------------------------------
 *   Function displayLegend()
 *
 *   Purpose: Display the specific legend of how the decks will be displayed.
 *
 *   @param  none
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayLegend()
{
	puts("\nThe legend is as follows:");
	printf(SUITS_DISPLAY_FORMAT, "Suits: ", "Hearts = ", HEARTS_SYMBOL,
		", Diamonds = ", DIAMONDS_SYMBOL, ", Clubs = ", CLUBS_SYMBOL,
		", and Spades = ", SPADES_SYMBOL);
	printf(RANKS_DISPLAY_FORMAT, "Ranks: ", "Ace = ", ACE_CHAR, ", Two = ",
			TWO_CHAR,",...", ", Ten = ", TEN_CHAR, ", Jack = ", JACK_CHAR,
			", Queen = ", QUEEN_CHAR,", and King = ", KING_CHAR);
}


/*---------------------------- printDeck ---------------------------------------
 *   Function printDeck(Card *const deck, int specificDeck)
 *
 *   Purpose: Prints a deck of cards using 2 for loops, first going by its suits
 *   and then by its ranks. Some ideas from:
 *   https://www.dreamincode.net/forums/topic/202808-creating-a-card-deck-in-c/
 *   were useful and it uses 2 array of chars where all the values of suits and
 *   ranks are stored form enumeration types to avoid magic numbers and
 *   increase readability.
 *   For the display of the symbols uses som UTF-8 encoding where:
 *   ♠ = U+2660 = "\xE2\x99\xA0" = "\u2660".
 *   ♣ = U+2663 = "\xE2\x99\xA3" = "\u2663".
 *   ♥ = U+2665 = "\xE2\x99\xA5" = "\u2665".
 *   ♦ = U+2666 = "\xE2\x99\xA6" = "\u2666".
 *	 For more information about the symbols please refer to:
 *   https://stackoverflow.com/questions/27133508
 *
 *   @param  Card *const deck
 *   @param  specificDeck
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void printDeck(Cards *const deck, int specificDeck)
{
	Cards *deckPtr = deck;
	if(specificDeck == ORDERED_DECK)
	{
		puts("\nOriginal Ordered Deck:");
	}
	else
	{
		puts("\nRandom Shuffled Deck:");
	}
	for(int suitsCounter = NO_VALUE; suitsCounter < SUITS_AMOUNT;
		suitsCounter++)
	{
		for(int ranksCounter = NO_VALUE; ranksCounter < RANKS_AMOUNT;
			ranksCounter++)
		{
			printf(CARD_DISPLAY_FORMAT, RANKS[deckPtr->rank % RANKS_AMOUNT],
			       SUITS[deckPtr->suit % SUITS_AMOUNT]);
			deckPtr++;
		}
		printf(NEWLINE);
	}
}


/*---------------------------- displayPlayerHands ------------------------------
 *   Function displayPlayerHands(Cards *playerHands, int players)
 *
 *   Purpose: This function displays in a clean, clear and aligned way the hands
 *   of every player. Using a helper function to reuse code.
 *
 *   @param  Cards *playerHands
 *   @param  int players
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayPlayerHands(Cards *playerHands, int players)
{
	printf("\nPlayer Hands: (dealt from top/front of deck)");
	displayHands(playerHands, players);
}


/*---------------------------- displayHands ------------------------------------
 *   Function displayHands(Cards *pCard, int players)
 *
 *   Purpose: Use 2 for loops to display the hands of each player every 5 cards.
 *
 *   @param  Cards *pCard
 *   @param  int players
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayHands(Cards *pCard, int players)
{
	Cards *deckPtr = pCard;
	int playerNumber = STARTING_AT_ONE;
	for(int playersCounter = NO_VALUE; playersCounter < players;
	    playersCounter++)
	{
		printf(PLAYER_DISPLAY_FORMAT, playerNumber);
		playerNumber++;
		for(int cardsCounter = NO_VALUE; cardsCounter < AMOUNT_OF_CARDS;
		    cardsCounter++)
		{
			printf(CARD_DISPLAY_FORMAT, RANKS[deckPtr->rank % RANKS_AMOUNT],
			       SUITS[deckPtr->suit % SUITS_AMOUNT]);
			deckPtr++;
		}
	}
}


/*---------------------------- displaySortPlayerHands --------------------------
 *   Function displaySortPlayerHands(Cards *playerHands, int players)
 *
 *   Purpose: This function displays in a clean, clear and aligned way the hands
 *   of every player after they have been sorted. Using a helper function to
 *   reuse code.
 *
 *   @param  Cards *playerHands
 *   @param  int players
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displaySortPlayerHands(Cards *playerHands, int players)
{
	printf(HEADER_DISPLAY_FORMAT, "Player Hands: sorted");
	displayHands(playerHands, players);
}


/*---------------------------- displayRankedPlayerHands ------------------------
 *   Function displayRankedPlayerHands(Cards playersCards[AMOUNT_OF_CARDS],
 *                             int players, int displayCode)
 *
 *   Purpose: This function displays in a clean, clear and aligned way the hands
 *   of every player after they have been sorted and with the respectively
 *   ranking. First test each hand to determine whats its ranking and then prints
 *   the hand next to its ranking.
 *
 *   @param  Cards playersCards[AMOUNT_OF_CARDS]
 *   @param  int players
 *   @param  int displayCode
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayRankedPlayerHands(Cards playersCards[AMOUNT_OF_CARDS],
                              int players, int displayCode)
{
	printf(HEADER_DISPLAY_FORMAT, "Player Hands: ranked");
	
	Cards *playerHandsPtr = playersCards;
	for(int playerCounter = NO_VALUE; playerCounter < players; playerCounter++)
	{
		testCases(playerHandsPtr, playerCounter);
		printHand(playerHandsPtr, displayCode,
				(playerCounter + NEXT));
		displayRankedHand(playerCounter);
		playerHandsPtr += AMOUNT_OF_CARDS;
	}
}


/*---------------------------- displayTestCases --------------------------------
 *   Function displayTestCases()
 *
 *   Purpose: This function displays in a clean, clear and aligned way the hands
 *   of every test case predefined in order to determine the effectiveness of the
 *   test functions. First test each hand to determine whats its ranking and then
 *   prints the hand next to its ranking.
 *
 *   @param  none
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayTestCases()
{
	printf(HEADER_DISPLAY_FORMAT, "Poker Hands: test");
	int dummyPlayer = NO_VALUE;
	const Cards *testPtr = NULL;
	for(int testCounter = NO_VALUE; testCounter < NUMBER_OF_TEST_CASES;
		testCounter++)
	{
		testPtr = TEST_CASES_PTR[testCounter];
		testCases(testPtr, testCounter);
		printHand(testPtr, TEST, dummyPlayer);
		displayRankedHand(testCounter);
	}
}


/*---------------------------- testCases ---------------------------------------
 *   Function testCases(const Cards pCard[AMOUNT_OF_CARDS], int playerCounter)
 *
 *   Purpose: Test an specific hand to determine what it is rank. Save the rank
 *   in a global array of type Cards to be easily accessible later on when
 *   displaying rankings.
 *
 *   @param  Cards pCard[AMOUNT_OF_CARDS]
 *   @param  int playerCounter
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void testCases(const Cards pCard[AMOUNT_OF_CARDS], int playerCounter)
{
	if(isStraightFlush(pCard))
	{playersRank[playerCounter].ranking = STRAIGHT_FLUSH;}
	else if(isFourOfAKind(pCard))
	{playersRank[playerCounter].ranking = FOUR_OF_A_KIND;}
	else if(isFullHouse(pCard))
	{playersRank[playerCounter].ranking = FULL_HOUSE;}
	else if(isFlush(pCard))
	{playersRank[playerCounter].ranking = FLUSH;}
	else if(isStraight(pCard))
	{playersRank[playerCounter].ranking = STRAIGHT;}
	else if(isThreeOfAKind(pCard))
	{playersRank[playerCounter].ranking = THREE_OF_A_KIND;}
	else if(isTwoPairs(pCard))
	{playersRank[playerCounter].ranking = TWO_PAIRS;}
	else if(isOnePair(pCard))
	{playersRank[playerCounter].ranking = ONE_PAIR;}
	else
	{playersRank[playerCounter].ranking = HIGH_CARD;}
}


/*---------------------------- displayRankedHand -------------------------------
 *   Function displayRankedHand(int counter)
 *
 *   Purpose: Display the specific ranking of each hand based on the ranking
 *   assigned by every test case.
 *
 *   @param  int counter
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayRankedHand(int counter)
{
	int rank = playersRank[counter].ranking;
	if(rank == STRAIGHT_FLUSH)
	{printf("%s", "- Straight Flush");}
	else if(rank == FOUR_OF_A_KIND)
	{printf("%s", "- Four of a Kind");}
	else if(rank == FULL_HOUSE)
	{printf("%s", "- Full House");}
	else if(rank == FLUSH)
	{printf("%s", "- Flush");}
	else if(rank == STRAIGHT)
	{printf("%s", "- Straight");}
	else if(rank == THREE_OF_A_KIND)
	{printf("%s", "- Three of a Kind");}
	else if(rank == TWO_PAIRS)
	{printf("%s", "- Two Pairs");}
	else if(rank == ONE_PAIR)
	{printf("%s", "- One Pair");}
	else
	{printf("%s", "- High Card");}
}


/*---------------------------- displayWinners ----------------------------------
 *   Function displayWinners(Cards playersCards[AMOUNT_OF_CARDS],
                              int players, int displayCode)
 *
 *   Purpose: This function displays in a clean, clear and aligned way the hands
 *   of every player after they have been sorted and with the respectively
 *   ranking. First test each hand to determine whats its ranking and then prints
 *   the hand next to its ranking. Then it finds the winner(s) and display a
 *   winner message next to the hand rank.
 *
 *   @param  Cards playersCards[AMOUNT_OF_CARDS]
 *   @param  int players
 *   @param  int displayCode
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void displayWinners(Cards playersCards[AMOUNT_OF_CARDS],
                    int players, int displayCode)
{
	printf(HEADER_DISPLAY_FORMAT, "Player Hands: winner(s)");
	findWinners(players);
	Cards *playerHandsPtr = playersCards;
	for(int playerCounter = NO_VALUE; playerCounter < players; playerCounter++)
	{
		testCases(playerHandsPtr, playerCounter);
		printHand(playerHandsPtr, displayCode,
				(playerCounter + NEXT));
		displayRankedHand(playerCounter);
		if(playersRank[playerCounter].status == WINNER)
		{
			printf("%s", " - Winner");
		}
		playerHandsPtr += AMOUNT_OF_CARDS;
	}
}


/*---------------------------- findWinners -------------------------------------
 *   Function findWinners(int players)
 *
 *   Purpose: Determine the winner(s) of the game based on the assigned ranking
 *   of each hand.
 *
 *   @param  int players
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void findWinners(int players)
{
	int maxRank = playersRank[NO_VALUE].ranking;
	for(int playerCounter = STARTING_AT_ONE; playerCounter < players;
		playerCounter++)
	{
		if(playersRank[playerCounter].ranking > maxRank)
		{
			maxRank = playersRank[playerCounter].ranking;
		}
	}
	for(int playerCounter = NO_VALUE; playerCounter < players; playerCounter++)
	{
		if(playersRank[playerCounter].ranking == maxRank)
		{
			playersRank[playerCounter].status = WINNER;
		}
	}
}


/*---------------------------- displayHands ------------------------------------
 *   Function printHand(const Cards *hand, int displayCode, int playerNumber)
 *
 *   Purpose: Display the five cards belonging to a specific hand.
 *
 *   @param  Cards *hand
 *   @param  int displayCode
 *   @param  int playerNumber
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void printHand(const Cards *hand, int displayCode, int playerNumber)
{
	if(displayCode == PLAYERS)
	{
		printf(PLAYER_DISPLAY_FORMAT, playerNumber);
	}
	else
	{
		printf("\n%s", "Hand: ");
	}
	
	const Cards *deckPtr = hand;
	for(int cardsCounter = NO_VALUE; cardsCounter < AMOUNT_OF_CARDS;
	    cardsCounter++)
	{
		printf(CARD_DISPLAY_FORMAT, RANKS[deckPtr->rank % RANKS_AMOUNT],
		       SUITS[deckPtr->suit % SUITS_AMOUNT]);
		deckPtr++;
	}
}


