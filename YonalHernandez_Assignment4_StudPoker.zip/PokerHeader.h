/*==============================================================================
 *   Source code:  PokerHeader.h
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #4 Stud Poker
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  29 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *   Language:  C
 *   Compile/Run:
 *      Using Makefile: $ make cleanAndBuild
 *      Not using Makefile:
 *  gcc PokerMain.c PokerCards.c PokerDisplay.c -o Poker.out -std=c99
 *  ./Cards.out "Number of Cards" "Numbers of Players"
 *
 *   Note:
 *   1. PokerHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) the program and clean the
 *   .o files.
 *   3. "Number of Cards" must be any positive integer number that wil be fixed
 *   to 5.
 *   4. "Numbers of Players" must be an integer numbers between [2-10].
 *   5. The use of the tag -std=c99 is needed in order to display the symbols
 *   for the suits and allows the declaration of the counter variable inside
 *   for loops.
 *
 *  +---------------------------------------------------------------------------
 *  Purpose:
 *  The purpose of this header is to link the elements of the different
 *  files that will be compiled together. It is very helpful because it lets
 *  different files to communicate and share resources making code more
 *  readable and allows the use of files for specific tasks.
 *
 * +---------------------------------------------------------------------------
 *  Constants:
 *  NEXT 1: Add 1 to arrive to the next element.
 *  NUMBERS_ONLY 1: Check if only number were entered in the command line input.
 *  DOUBLE_INITIALIZATION 0.0: Initialize a double number.
 *  STARTING_AT_ONE 1: Avoid number 0.
 *  MAX_AMOUNT_OF_CARDS 52: Amount of cards in a deck
 *  MIN_PLAYERS 2: Minimum players allowed.
 *  MAX_PLAYERS 10: Maximum players allowed
 *  AMOUNT_OF_CARDS 5: Amount of cards in a game of stud poker.
 *  NO_VALUE 0: Avoid magic number 0 when initializing.
 *  NUMBER_OF_ARGS 3: Amount of arguments expected at command line input.
 *  FIRST_ARG 1: Avoid magic number.
 *  SECOND_ARG 2: Avoid magic number.
 *  SUITS_AMOUNT 4: Possible suits in card.
 *  RANKS_AMOUNT 13: Possible rank in a card.
 *  HEARTS_SYMBOL "\u2665": Encoding for the Heart symbol
 *  DIAMONDS_SYMBOL "\u2666": Encoding for the Diamond symbol
 *  CLUBS_SYMBOL "\u2663": Encoding for the Clubs symbol
 *  SPADES_SYMBOL "\u2660": Encoding for the Spade symbol
 *  SUITS_DISPLAY_FORMAT "\t%10s%s'%s '%s'%s '%s'%s '%s'%s '\n": Helpful to
 *      avoid mistakes when printing.
 *  RANKS_DISPLAY_FORMAT "\t%10s%s'%c'%s'%c'%s%s'%c'%s'%c'%s'%c'%s'%c'\n":
 *      Helpful to avoid mistakes when printing.
 *  CARD_DISPLAY_FORMAT " [ %c-%s ] ": Helpful to avoid mistakes when printing.
 *  PLAYER_DISPLAY_FORMAT "\n[Player %2d] - ": Helpful to avoid mistakes when
 *      printing.
 *  HEADER_DISPLAY_FORMAT "\n\n%s": Helpful to avoid mistakes when printing.
 *  NEWLINE "\n": Helpful to avoid mistakes when printing.
 *  SAME_TWO 2: Helpful to find a pair of cards.
 *  SAME_THREE 3: Helpful to ask for three cards with the same rank.
 *  SAME_FOUR 4: Helpful to ask for four cards with the same rank.
 *  NUMBER_OF_TEST_CASES 9: Represent the different ranks that a specific hand
 *      can take.
 *
 *============================================================================*/

#include <stdio.h>
#include <stdlib.h> //For the use of atoi(), atof(), rand() and srand().
#include <time.h>   //Contains prototype for function time.

//-- Constants --//
#define NEXT 1
#define NUMBERS_ONLY 1
#define DOUBLE_INITIALIZATION 0.0
#define STARTING_AT_ONE 1
#define MAX_AMOUNT_OF_CARDS 52
#define MIN_PLAYERS 2
#define MAX_PLAYERS 10
#define AMOUNT_OF_CARDS 5
#define NO_VALUE 0
#define NUMBER_OF_ARGS 3
#define FIRST_ARG 1
#define SECOND_ARG 2
#define SUITS_AMOUNT 4
#define RANKS_AMOUNT 13
#define HEARTS_SYMBOL "\u2665"
#define DIAMONDS_SYMBOL "\u2666"
#define CLUBS_SYMBOL "\u2663"
#define SPADES_SYMBOL "\u2660"
#define SUITS_DISPLAY_FORMAT "\t%10s%s'%s '%s'%s '%s'%s '%s'%s '\n"
#define RANKS_DISPLAY_FORMAT "\t%10s%s'%c'%s'%c'%s%s'%c'%s'%c'%s'%c'%s'%c'\n"
#define CARD_DISPLAY_FORMAT " [ %c-%s ] "
#define PLAYER_DISPLAY_FORMAT "\n[Player %2d] - "
#define HEADER_DISPLAY_FORMAT "\n\n%s"
#define NEWLINE "\n"
#define SAME_TWO 2
#define SAME_THREE 3
#define SAME_FOUR 4
#define NUMBER_OF_TEST_CASES 9


//-- Enumeration Types --//
enum ranksChar  //Char value for ranks when printing
{
	TWO_CHAR = '2', THREE_CHAR = '3', FOUR_CHAR = '4',
	FIVE_CHAR = '5', SIX_CHAR = '6', SEVEN_CHAR = '7', EIGHT_CHAR = '8',
	NINE_CHAR = '9', TEN_CHAR = 'T', JACK_CHAR = 'J', QUEEN_CHAR = 'Q',
	KING_CHAR = 'K', ACE_CHAR = 'A'
};
enum ranksValues    //Numeric value for each rank
{
	TWO_NUM, THREE_NUM, FOUR_NUM, FIVE_NUM, SIX_NUM, SEVEN_NUM,
	EIGHT_NUM, NINE_NUM, TEN_VAL, JACK_VAL, QUEEN_VAL, KING_VAL, ACE_VAL
};
enum suitsValues    //Numeric value for each suit
{
	HEARTS_NUM, DIAMONDS_NUM, CLUBS_NUM, SPADES_NUM
};
enum errors     //Different errors to be used
{
    ERROR = 1, NO_ERROR = 0, NOT_THREE_ARGS = -1, INTEGERS_ONLY = -2,
    CARDS_NOT_IN_RANGE = -3, PLAYERS_NOT_IN_RANGE = -4
};
enum cardRanking    //Numeric value of the ranking of the cards.
{
	HIGH_CARD = 1, ONE_PAIR, TWO_PAIRS, THREE_OF_A_KIND, STRAIGHT, FLUSH,
	FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH
};
enum cardSequence   //Easy to refer to a specif card in a hand
{
	FIRST_CARD, SECOND_CARD, THIRD_CARD, FORTH_CARD, FIFTH_CARD
};
enum boolean    //For return purposes
{
	FALSE, TRUE
};
enum displayCode    //Specific code for printing
{
	PLAYERS, ORDERED_DECK, SHUFFLED_DECK, TEST, WINNER
};


//-- Card Structure Definition --//
struct card
{
	int rank;
	int suit;
};
typedef struct card Cards;

struct playerRanking
{
	int ranking;
	int status;
};
typedef struct playerRanking Players;


//-- Function Prototypes from PokerCards --//
void fillOriginalDeck(Cards *deck);
void shuffleDeck(Cards *deck);
void dealCardsToPlayers(Cards *deck, Cards *playersCards);
void sortPlayerHands(Cards *playersCards, int players);
int isStraightFlush(const Cards playerHands[AMOUNT_OF_CARDS]);
int isFourOfAKind(const Cards playerHands[AMOUNT_OF_CARDS]);
int isFullHouse(const Cards playerHands[AMOUNT_OF_CARDS]);
int isFlush(const Cards playerHands[AMOUNT_OF_CARDS]);
int isStraight(const Cards playerHands[AMOUNT_OF_CARDS]);
int isThreeOfAKind(const Cards playerHands[AMOUNT_OF_CARDS]);
int isTwoPairs(const Cards playerHands[AMOUNT_OF_CARDS]);
int isOnePair(const Cards playerHands[AMOUNT_OF_CARDS]);


//-- Function Prototypes from PokerDisplay --//
int displayErrorMessage(int error);
void displayLegend();
void printDeck(Cards *deck, int specificDeck);
void displayPlayerHands(Cards *playerHands,	int players);
void displaySortPlayerHands(Cards *playerHands, int players);
void displayTestCases();
void displayRankedPlayerHands(Cards playersCards[AMOUNT_OF_CARDS],
                              int players, int displayCode);
void displayWinners(Cards playersCards[AMOUNT_OF_CARDS],
                              int players, int displayCode);

