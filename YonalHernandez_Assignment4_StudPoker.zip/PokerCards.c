/*==============================================================================
 *   Source code:  PokerCards.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #4 Stud Poker
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  29 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *      Using Makefile: $ make cleanAndBuild
 *      Not using Makefile:
 *  gcc PokerMain.c PokerCards.c PokerDisplay.c -o Poker.out -std=c99
 *  ./Cards.out "Number of Cards" "Numbers of Players"
 *
 *   Note:
 *   1. PokerHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) the program and clean the
 *   .o files.
 *   3. "Number of Cards" must be any positive integer number that wil be fixed
 *   to 5.
 *   4. "Numbers of Players" must be an integer numbers between [2-10].
 *   5. The use of the tag -std=c99 is needed in order to display the symbols
 *   for the suits and allows the declaration of the counter variable inside
 *   for loops.
 *
 *  +---------------------------------------------------------------------------
 *  Purpose:
 *  This file takes care of the process that creates the deck of cards in
 *  an ordered way, then simulates the shuffle of the cards and later deals
 *  cards to players. After that, rank the hands using the selection sort method.
 *  Find the specific ranking for every hand in some cases with the help of the
 *  bucket sort method. Everything related with the handling of the cards.
 *
 *============================================================================*/


#include "PokerHeader.h"//For shared elements.


//-- Function Prototypes --//
void selectionSort(Cards *pCard, int playerCounter);
int *bucketSort(const Cards *pCard);
int aceOnFirstPosition(const Cards *pCard);
//-- Other Function prototypes listed on CardsHeader.h --//




/*---------------------------- sortPlayerHands ---------------------------------
 *   Function sortPlayerHands(Cards *playersCards, int players)
 *
 *   Purpose: This function sort the hands of the players in order to easily
 *   compare and display the cards later. Use a function helper to execute the
 *   selection sort method and it runs from 0 to the amount of players.
 *
 *   @param  Cards *playersCards
 *   @param  int players
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void sortPlayerHands(Cards *playersCards, int players)
{
 	for(int playerCounter = NO_VALUE; playerCounter < players;
		playerCounter++)
	{
 		selectionSort(playersCards, playerCounter);
	}
}


/*---------------------------- selectionSort -----------------------------------
 *   Function selectionSort(Cards *pCard, int playerCounter)
 *
 *   Purpose: Use the selection sort criteria to sort each hand (5 cards). For
 *   more information please refer to:
 *   https://www.geeksforgeeks.org/selection-sort/
 *
 *   @param  Cards *pCard
 *   @param  int playerCounter
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void selectionSort(Cards *pCard, int playerCounter)
{
	Cards *leftHandPtr = NULL;
	Cards *rightHandPtr = NULL;
	int card = playerCounter * AMOUNT_OF_CARDS;
	int limit = AMOUNT_OF_CARDS + card;
	for(card; card < limit; card++)
	{
		leftHandPtr = &pCard[card];
		Cards minValue = pCard[card];
		for(int cardCounter = card + NEXT; cardCounter < limit;
		    cardCounter++)
		{
			rightHandPtr = &pCard[cardCounter];
			if(leftHandPtr->rank > rightHandPtr->rank)
			{
				*leftHandPtr = *rightHandPtr;
				*rightHandPtr = minValue;
				minValue = *leftHandPtr;
			}
		}
	}
}


/*---------------------------- fillOriginalDeck ------------------------------
 *   Function fillOriginalDeck(Card *deck)
 *
 *   Purpose: This function fills an array of 52 cards with integers in
 *   increasing order. Each card has a rank and a suit.
 *
 *   @param  Card *deck
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void fillOriginalDeck(Cards *deck)
{
	for(int deckCounter = NO_VALUE; deckCounter < MAX_AMOUNT_OF_CARDS;
		deckCounter++)
	{
		deck[deckCounter].rank = (deckCounter % RANKS_AMOUNT);
		deck[deckCounter].suit = (deckCounter / RANKS_AMOUNT);
	}
}


/*---------------------------- shuffleDeck -------------------------------------
 *   Function shuffleDeck(Card *deck)
 *
 *   Purpose: This function simulates the shuffling of a deck of cards by
 *   randomly swapping the numbers inside the array. Use of some ideas from the
 *   Fisher and Yates' method and from its modern implementation in the
 *   Sattolo's algorithm. For more information refer to:
 *https://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle#The_modern_algorithm
 *   The algorithm iterates throughout an array using two indexes and then swap
 *   those numbers. The first number is the counter of the for loop from first
 *   to last element while the second index is a random number for the purpose
 *   of the shuffling. To generate random numbers we use the function rand()
 *   that returns a pseudo-random number in the range of 0 to RAND_MAX.
 *   RAND_MAX is a constant whose default value may vary between implementations
 *   but it is granted to be at least 32767. We find the remainder of rand() and
 *   52 to set the number in the range we are working [0-51].
 *   For more information please refer to:
 *   https://www.tutorialspoint.com/c_standard_library/c_function_rand.htm
 *   To assure the random number is in range we find the remainder of the number
 *   with 52.
 *
 *   @param  Card *deck
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void shuffleDeck(Cards *deck)
{
	for(int deckCounter = NO_VALUE; deckCounter < MAX_AMOUNT_OF_CARDS;
		deckCounter++)
	{
		int randomIndex = rand() % MAX_AMOUNT_OF_CARDS;
		Cards swapValue = deck[deckCounter];
		deck[deckCounter] = deck[randomIndex];
		deck[randomIndex] = swapValue;
	}
}


/*---------------------------- dealCardsToPlayers ------------------------------
 *   Function dealCardsToPlayers(Cards *deck, Cards *playersCards)
 *
 *   Purpose: This function takes the cards from the top of a shuffled deck of
 *   cards, where the top means the card in index 0 and
 *   then save them into an array of the same size that simulates the hands of
 *   each player.
 *
 *   @param  Card *deck
 *   @param  Cards *playersCards
 *
 *  @return  none
 *----------------------------------------------------------------------------*/
void dealCardsToPlayers(Cards *deck, Cards *playersCards)
{
	for(int deckCounter = NO_VALUE; deckCounter < MAX_AMOUNT_OF_CARDS;
		deckCounter++)
	{
		playersCards[deckCounter] =	deck[deckCounter];
	}
}


/*---------------------------- isStraightFlush ---------------------------------
 *   Function isStraightFlush(const Cards playerHands[AMOUNT_OF_CARDS])
 *
 *   Purpose: This function test if a specific hand satisfy the criteria of
 *   Straight Flush (5 cards in ascending order with the same suit). It consider
 *   that the ace can be at the start or at the end.
 *   For mor information please refer to:
 *   https://www.pokerstars.com/poker/games/rules/hand-rankings/
 *
 *   @param  Cards playerHands[AMOUNT_OF_CARDS]
 *
 *  @return  STRAIGHT_FLUSH or FALSE
 *----------------------------------------------------------------------------*/
int isStraightFlush(const Cards playerHands[AMOUNT_OF_CARDS])
{
	const Cards *firstCard = &playerHands[FIRST_CARD];
	const Cards *secondCard = &playerHands[SECOND_CARD];
	const Cards *thirdCard = &playerHands[THIRD_CARD];
	const Cards *forthCard = &playerHands[FORTH_CARD];
	const Cards *fifthCard = &playerHands[FIFTH_CARD];
	
	if(aceOnFirstPosition(playerHands))
	{
		return STRAIGHT_FLUSH;
	}
	else
	{
		if((firstCard->suit == secondCard->suit) &&
		(firstCard->suit == thirdCard->suit) &&
		(firstCard->suit == forthCard->suit) &&
		(firstCard->suit == fifthCard->suit))
		{
			if ((firstCard->rank == (secondCard->rank - NEXT)) &&
			    (secondCard->rank == (thirdCard->rank - NEXT)) &&
			    (thirdCard->rank == (forthCard->rank - NEXT)) &&
			    (forthCard->rank == (fifthCard->rank - NEXT)))
			{
				return STRAIGHT_FLUSH;
			}
		}
	}
	return FALSE;
}


/*---------------------------- aceOnFirstPosition ------------------------------
 *   Function aceOnFirstPosition(const Cards *pCard)
 *
 *   Purpose: Helper function for isStraightFlush in order to not pass the 30
 *   lines per function. Function test if the ace is found at the first card of
 *   the hand and in positive case if it satisfy the condition to be considered
 *   STRAIGHT_FLUSH.
 *
 *   @param   Cards *pCard
 *
 *  @return  TRUE or FALSE
 *----------------------------------------------------------------------------*/
int aceOnFirstPosition(const Cards *pCard)
{
	const Cards *firstCard = &pCard[FIRST_CARD];
	const Cards *secondCard = &pCard[SECOND_CARD];
	const Cards *thirdCard = &pCard[THIRD_CARD];
	const Cards *forthCard = &pCard[FORTH_CARD];
	const Cards *fifthCard = &pCard[FIFTH_CARD];
	
	if((firstCard->rank == ACE_VAL) && (secondCard->rank == TWO_NUM) &&
	   (thirdCard->rank == THREE_NUM) && (forthCard->rank == FOUR_NUM) &&
	   (forthCard->rank == FOUR_NUM) && (fifthCard->rank == FIVE_NUM))
	{
		if ((firstCard->suit == secondCard->suit) &&
		    (secondCard->suit == thirdCard->suit) &&
		    (thirdCard->suit == forthCard->suit) &&
		    (forthCard->suit == fifthCard->suit))
		{
			return TRUE;
		}
	}
	return FALSE;
}


/*---------------------------- isFourOfAKind ---------------------------------
 *   Function isFourOfAKind(const Cards playerHands[AMOUNT_OF_CARDS])
 *
 *   Purpose: This function test if a specific hand satisfy the criteria of
 *   Four of the Kind (four cards with the same rank).
 *   For mor information please refer to:
 *   https://www.pokerstars.com/poker/games/rules/hand-rankings/
 *
 *   @param  Cards playerHands[AMOUNT_OF_CARDS]
 *
 *  @return  FOUR_OF_A_KIND or FALSE
 *----------------------------------------------------------------------------*/
int isFourOfAKind(const Cards playerHands[AMOUNT_OF_CARDS])
{
	int *bucketSortPtr = bucketSort(playerHands);
	for(int bucketCounter = NO_VALUE; bucketCounter < RANKS_AMOUNT;
		bucketCounter++)
	{
		if(bucketSortPtr[bucketCounter] == SAME_FOUR)
		{
			return FOUR_OF_A_KIND;
		}
	}
	return FALSE;
}


/*---------------------------- isFullHouse ---------------------------------
 *   Function isFullHouse(const Cards playerHands[AMOUNT_OF_CARDS])
 *
 *   Purpose: This function test if a specific hand satisfy the criteria of
 *   Full House (Three of a kind plus a pair).
 *   For mor information please refer to:
 *   https://www.pokerstars.com/poker/games/rules/hand-rankings/
 *
 *   @param  Cards playerHands[AMOUNT_OF_CARDS]
 *
 *  @return  FULL_HOUSE or FALSE
 *----------------------------------------------------------------------------*/
int isFullHouse(const Cards playerHands[AMOUNT_OF_CARDS])
{
	const Cards *firstCard = &playerHands[FIRST_CARD];
	const Cards *secondCard = &playerHands[SECOND_CARD];
	const Cards *thirdCard = &playerHands[THIRD_CARD];
	const Cards *forthCard = &playerHands[FORTH_CARD];
	const Cards *fifthCard = &playerHands[FIFTH_CARD];
	
	if(((firstCard->rank == secondCard->rank == thirdCard->rank) &&
	    (forthCard->rank == fifthCard->rank)) ||
	   ((thirdCard->rank == forthCard->rank == fifthCard->rank) &&
	    (firstCard->rank == secondCard->rank)))
	{
		return FULL_HOUSE;
	}
	return FALSE;
}

/*---------------------------- isFlush ---------------------------------
 *   Function isFlush(const Cards playerHands[AMOUNT_OF_CARDS])
 *
 *   Purpose: This function test if a specific hand satisfy the criteria of
 *   FLUSH (Every card has the same suit).
 *   For mor information please refer to:
 *   https://www.pokerstars.com/poker/games/rules/hand-rankings/
 *
 *   @param  Cards playerHands[AMOUNT_OF_CARDS]
 *
 *  @return  FLUSH or FALSE
 *----------------------------------------------------------------------------*/
int isFlush(const Cards playerHands[AMOUNT_OF_CARDS])
{
	const Cards *firstCard = &playerHands[FIRST_CARD];
	const Cards *secondCard = &playerHands[SECOND_CARD];
	const Cards *thirdCard = &playerHands[THIRD_CARD];
	const Cards *forthCard = &playerHands[FORTH_CARD];
	const Cards *fifthCard = &playerHands[FIFTH_CARD];
	
	if((firstCard->suit == secondCard->suit) &&
	   (firstCard->suit == thirdCard->suit) &&
	   (firstCard->suit == forthCard->suit) &&
	   (firstCard->suit == fifthCard->suit))
	{
		return FLUSH;
	}
	return FALSE;
}


/*---------------------------- isStraight ---------------------------------
 *   Function isStraight(const Cards playerHands[AMOUNT_OF_CARDS])
 *
 *   Purpose: This function test if a specific hand satisfy the criteria of
 *   STRAIGHT (Ranks are consecutive).
 *   For mor information please refer to:
 *   https://www.pokerstars.com/poker/games/rules/hand-rankings/
 *
 *   @param  Cards playerHands[AMOUNT_OF_CARDS]
 *
 *  @return  STRAIGHT or FALSE
 *----------------------------------------------------------------------------*/
int isStraight(const Cards playerHands[AMOUNT_OF_CARDS])
{
	const Cards *firstCard = &playerHands[FIRST_CARD];
	const Cards *secondCard = &playerHands[SECOND_CARD];
	const Cards *thirdCard = &playerHands[THIRD_CARD];
	const Cards *forthCard = &playerHands[FORTH_CARD];
	const Cards *fifthCard = &playerHands[FIFTH_CARD];
	
	if(firstCard->rank == ACE_VAL)
	{
		if((secondCard->rank == TWO_NUM) &&
		   (thirdCard->rank == THREE_NUM) &&
		   (forthCard->rank == FOUR_NUM) &&
		   (fifthCard->rank == FIVE_NUM))
		{
			return STRAIGHT;
		}
	}
	
	if((firstCard->rank == (secondCard->rank - NEXT)) &&
	   (secondCard->rank == (thirdCard->rank - NEXT)) &&
	   (thirdCard->rank == (forthCard->rank - NEXT)) &&
	   (forthCard->rank == (fifthCard->rank - NEXT)))
	{
		return STRAIGHT;
	}
	return FALSE;
}


/*---------------------------- isThreeOfAKind ---------------------------------
 *   Function isThreeOfAKind(const Cards playerHands[AMOUNT_OF_CARDS])
 *
 *   Purpose: This function test if a specific hand satisfy the criteria of
 *   THREE_OF_A_KIND (Three cards with the same rank).
 *   For mor information please refer to:
 *   https://www.pokerstars.com/poker/games/rules/hand-rankings/
 *
 *   @param  Cards playerHands[AMOUNT_OF_CARDS]
 *
 *  @return  THREE_OF_A_KIND or FALSE
 *----------------------------------------------------------------------------*/
int isThreeOfAKind(const Cards playerHands[AMOUNT_OF_CARDS])
{
	int *bucketSortPtr = bucketSort(playerHands);
	for(int bucketCounter = NO_VALUE; bucketCounter < RANKS_AMOUNT;
		bucketCounter++)
	{
		if(bucketSortPtr[bucketCounter] == SAME_THREE)
		{
			return THREE_OF_A_KIND;
		}
	}
	return FALSE;
}


/*---------------------------- isTwoPairs ---------------------------------
 *   Function isTwoPairs(const Cards playerHands[AMOUNT_OF_CARDS])
 *
 *   Purpose: This function test if a specific hand satisfy the criteria of
 *   TWO_PAIRS (Two pair of cards with the same rank).
 *   For mor information please refer to:
 *   https://www.pokerstars.com/poker/games/rules/hand-rankings/
 *
 *   @param  Cards playerHands[AMOUNT_OF_CARDS]
 *
 *  @return  TWO_PAIRS or FALSE
 *----------------------------------------------------------------------------*/
int isTwoPairs(const Cards playerHands[AMOUNT_OF_CARDS])
{
	int *bucketSortPtr = bucketSort(playerHands);
	int pairsAmount = NO_VALUE;
	for(int bucketCounter = NO_VALUE; bucketCounter < RANKS_AMOUNT;
		bucketCounter++)
	{
		if(bucketSortPtr[bucketCounter] == SAME_TWO)
		{
			pairsAmount++;
		}
		if(pairsAmount == SAME_TWO)
		{
			return TWO_PAIRS;
		}
	}
	return FALSE;
}


/*---------------------------- isOnePair ---------------------------------
 *   Function isOnePair(const Cards playerHands[AMOUNT_OF_CARDS])
 *
 *   Purpose: This function test if a specific hand satisfy the criteria of
 *   ONE_PAIR (One pair of cards with the same rank).
 *   For mor information please refer to:
 *   https://www.pokerstars.com/poker/games/rules/hand-rankings/
 *
 *   @param  Cards playerHands[AMOUNT_OF_CARDS]
 *
 *  @return  ONE_PAIR or FALSE
 *----------------------------------------------------------------------------*/
int isOnePair(const Cards playerHands[AMOUNT_OF_CARDS])
{
	int *bucketSortPtr = bucketSort(playerHands);
	for(int bucketCounter = NO_VALUE; bucketCounter < RANKS_AMOUNT;
		bucketCounter++)
	{
		if(bucketSortPtr[bucketCounter] == SAME_TWO)
		{
			return ONE_PAIR;
		}
	}
	return FALSE;
}


/*---------------------------- bucketSort --------------------------------------
 *   Function *bucketSort(const Cards *pCard)
 *
 *   Purpose: Use to speed the selection sort criteria by counting the
 *   appearance of each card in a single hand.
 *   For more information please refer to:
 *   https://www.geeksforgeeks.org/bucket-sort-2/
 *
 *   @param  Cards *pCard
 *
 *  @return  int *tempPtr
 *----------------------------------------------------------------------------*/
int *bucketSort(const Cards *pCard)
{
	int *tempPtr = NULL;
	int bucketSortArray[RANKS_AMOUNT] = {NO_VALUE};
	int bucketIndex = NO_VALUE;
	for(int bucketSortCounter = FIRST_CARD; bucketSortCounter < AMOUNT_OF_CARDS;
	    bucketSortCounter++)
	{
		bucketIndex = pCard[bucketSortCounter].rank;
		bucketSortArray[bucketIndex]++;
	}
	tempPtr = bucketSortArray;
	return tempPtr;
}