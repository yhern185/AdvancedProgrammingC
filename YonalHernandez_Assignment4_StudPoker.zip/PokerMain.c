/*==============================================================================
 *   Source code:  PokerMain.c
 *        Author:  Yonal Hernandez
 *    Student ID:  6178656
 *    Assignment:  Program #4 Stud Poker
 *
 *        Course:  COP 4338 (Advanced Programming)
 *       Section:  U04 1198
 *    Instructor:  William Feild
 *      Due Date:  29 October, 2019, at the beginning of class
 *
 *	I hereby certify that this collective work is my own
 *	and none of it is the work of any other person or entity.
 *	_______________Yonal Hernandez_______________________
 *
 *      Language:  C
 *   Compile/Run:
 *      Using Makefile: $ make cleanAndBuild
 *      Not using Makefile:
 *  gcc PokerMain.c PokerCards.c PokerDisplay.c -o Poker.out -std=c99
 *  ./Cards.out "Number of Cards" "Numbers of Players"
 *
 *   Note:
 *   1. PokerHeader.h is needed in the same folder, it contains the
 *   shared elements between files.
 *   2. Makefile is needed in the same directory, it contains targets with some
 *   macros defined in order to easily compile (build) the program and clean the
 *   .o files.
 *   3. "Number of Cards" must be any positive integer number that wil be fixed
 *   to 5.
 *   4. "Numbers of Players" must be an integer numbers between [2-10].
 *   5. The use of the tag -std=c99 is needed in order to display the symbols
 *   for the suits and allows the declaration of the counter variable inside
 *   for loops.
 *
 *  +---------------------------------------------------------------------------
 *
 *  Description: Program simulates a game of Stud Poker, use a deck of cards and
 *      deal hands of cards.
 *      Conventional deck of cards has 52 cards: 13 ranks and 4 suits. The
 *      legend is as follows:
 *      Suits:	Hearts = '♥', Diamonds = '♦', Clubs = '♣', and Spades = '♠'
 *      Ranks:	Ace='A', Two='2',..., Ten='T', Jack='J', Queen='Q', and King='K'
 *      Simulation is able to create a deck of cards, display the original deck,
 *      shuffle the deck, display the shuffled deck, deal (from the top of the
 *      deck) the specified number of cards (5) to the specified number of players
 *      (as per the command-line), sort each hand, rank each hand and display
 *      each of the hands of cards showing the winners along with test cases
 *      that shows the functions works correctly.
 *      As per requirements, hands should be separate entities from the deck; Four
 *      source code files are used, one for main(), one the handle the deck of
 *      cards, another to take care of the output and display messages and other
 *      to rank the hands of the players.
 *      The use of a proper user-defined header file is useful in order to share
 *      elements between files. Use of a Makefile is required and used to easily
 *      and clean the .o files amd compile, Makefile will only clean and compile,
 *      not execute.
 *
 *  Input: Accept input via the command-line arguments only. Fully validate
 *      command-line input. Input will specify the # of cards/hand and the # of
 *      hands (players), in that order. Input will accept any positive integer
 *      for the number of cards, this integer will be fixed to the number 5. And
 *      a integer number between [2-10] for the number of players.
 *
 *  Output: Display a legend for ranks and suits. Display the original deck
 *      (ordered) and the shuffled deck (random), display each of the
 *      player’s hands of cards, display the sorted hands, and then display the
 *      sorted hands - labeling each hand with its poker hand rank. Next, display
 *      a list of winner(s), or clearly designate the winner(s) with the labeled
 *      hands. After the game is concluded, program executes a “test function”
 *      that passes a sequence of pre-set poker hands, one for each poker-rank
 *      hand, in order to validate that each poker-ranking function correctly
 *      ranks such hands. Decks, hands and cards should be clean, clear,
 *      aligned, appropriately labeled, and easy to read. Symbols (♥ ♦ ♣ ♠)for
 *      suits are use because are attractive.
 *      For the display of the symbols uses som UTF-8 encoding where:
 *      ♠ = U+2660 = "\xE2\x99\xA0" = "\u2660".
 *	    ♣ = U+2663 = "\xE2\x99\xA3" = "\u2663".
 *	    ♥ = U+2665 = "\xE2\x99\xA5" = "\u2665".
 *	    ♦ = U+2666 = "\xE2\x99\xA6" = "\u2666".
 *	    For more information about the symbols please refer to:
 *      https://stackoverflow.com/questions/27133508
 *
 *  Process:
 *      1. Validate input in the command line checking if the amount of arguments
 *      is exactly 3, if there are just number (and nothing else follows), is
 *      any floating point value, if amount of cards is a positive integer, if
 *      amount of players is in range [2-10].
 *      2. Use a structure to define each card based on its rank and suit.
 *      3. Store numbers of players found in the command line input in a variable
 *      of integer type.
 *      3. Display legend of cards.
 *      4. Create original deck of cards.
 *      5. Display original ordered deck of cards in a clean fashion way so the
 *      program will show the deck is ordered initially.
 *      6. Seed the random number generator with srand(), runs only once in the
 *      main. It decides where to start generating numbers. Otherwise, rand()
 *      will generate the same sequence every time. For more information please
 *      refer to:
 *      https://www.tutorialspoint.com/c_standard_library/c_function_srand.htm
 *      7. Shuffle deck of original ordered cards using rand() function and the
 *      ideas from Fisher, Yates and Sattolos algorithm to swap numbers inside
 *      the array simulating shuffling.
 *      8. Deal cards to players from the top of the deck (the top of the deck
 *      it is the first position of the deck of cards).
 *      9. Display cards from players.
 *      10. Sort and display hands of players using the selection sort method.
 *      11. Rank and display hand of players.
 *      12. Display hands showing winner(s).
 *      13. Display test cases.
 *      14. Create Makefile per requirements in order to clean and compile the
 *      program.
 *
 *   Required Features Not Included:
 *              None
 *
 *   Known Bugs:
 *              None
 *============================================================================*/

#include "PokerHeader.h" //For shared elements.


//-- Function Prototypes --//
int validateInput(int argc, char **argv);
int checkForIntegersOnly(char **argv);


int main(int argc, char *argv[])
{
	Cards deckOfCards[MAX_AMOUNT_OF_CARDS] = {NO_VALUE};
	Cards playerHands[MAX_AMOUNT_OF_CARDS] = {NO_VALUE};
	if(validateInput(argc, argv))
	{
		return ERROR;
	}
	const int NUMBER_OF_PLAYERS = atoi(argv[SECOND_ARG]);
	displayLegend();
	fillOriginalDeck(deckOfCards);
	printDeck(deckOfCards, ORDERED_DECK);
	srand(time(NULL));
	shuffleDeck(deckOfCards);
	printDeck(deckOfCards, SHUFFLED_DECK);
	dealCardsToPlayers(deckOfCards, playerHands);
	displayPlayerHands(playerHands, NUMBER_OF_PLAYERS);
	sortPlayerHands(playerHands, NUMBER_OF_PLAYERS);
	displaySortPlayerHands(playerHands, NUMBER_OF_PLAYERS);
	displayRankedPlayerHands(playerHands, NUMBER_OF_PLAYERS, PLAYERS);
	displayWinners(playerHands, NUMBER_OF_PLAYERS, PLAYERS);
	displayTestCases();
	
	return NO_ERROR;
}


/*---------------------------- validateInput -----------------------------------
 *   Function validateInput(int argc, char **argv)
 *
 *   Purpose: Validate the user input in order to obtain the number of
 *   cards (any positive integer that will be fixed to 5) and the number of
 *   players (integer number between [2-10]) respectively. We use the value from
 *   argc (for argument count) which hold the number of command line
 *   arguments the program was invoked with. The arguments will be save in
 *   *argv (for argument vector) is a pointer to an array of strings
 *   that contains the arguments one per string. First the function makes sure
 *   that the amount or arguments is exactly 3. Then call a helper function to
 *   make sure that the arguments passed in the command line are integer numbers.
 *   Then validates the range of cards and players. For
 *   more information about argc and argv please refer to:
 *   https://www.tutorialspoint.com/cprogramming/c_command_line_arguments.htm
 *
 *   @param  argc
 *   @param  **argv
 *
 *  @return  errorValue
 *----------------------------------------------------------------------------*/
int validateInput(int argc, char **argv)
{
	int errorValue = NO_ERROR;
	if(argc != NUMBER_OF_ARGS)
	{
		errorValue = displayErrorMessage(NOT_THREE_ARGS);
	}
	else if(checkForIntegersOnly(argv))
	{
		errorValue = displayErrorMessage(INTEGERS_ONLY);
	}
	else
	{
		int cardsNumber = atoi(argv[FIRST_ARG]);
		int playersNumber = atoi(argv[SECOND_ARG]);
		if((playersNumber < MIN_PLAYERS) || (playersNumber > MAX_PLAYERS))
		{
			errorValue = displayErrorMessage(PLAYERS_NOT_IN_RANGE);
		}
		else if (cardsNumber < NO_VALUE)
		{
			errorValue = displayErrorMessage(CARDS_NOT_IN_RANGE);
		}
	}
	return errorValue;
}

/*---------------------------- checkForIntegersOnly ----------------------------
 *   Function checkForIntegersOnly(char **argv)
 *
 *   Purpose: This function guaranties that the arguments passed in the command
 *   line are integer numbers only . In order to do so use the function sscanf()
 *   that reads formatted input from an string and on success return the number
 *   of variables filled. In the case of an input failure before any data could
 *   be successfully read, EOF is returned. For more info please refer to:
 *   https://www.tutorialspoint.com/c_standard_library/c_function_sscanf.htm
 *   Then uses the functions atoi() that returns the converted integral number
 *   as an int value. If no valid conversion could be performed, it returns zero.
 *   And atof() that does the same but returns a floating point value. They are
 *   very useful to retrieve a value from an array of string and compare then in
 *   case of floating point input in the command line. For more information
 *   please refer to:
 *   https://www.tutorialspoint.com/c_standard_library/c_function_atoi.htm
 *   https://www.tutorialspoint.com/c_standard_library/c_function_atof.htm
 *
 *   @param  **argv
 *
 *  @return  errorValue
 *----------------------------------------------------------------------------*/
int checkForIntegersOnly(char **argv)
{
	int errorValue = NO_ERROR;
	double receivedValue = DOUBLE_INITIALIZATION;
	char dummyValue = NO_VALUE;
	for(int argsCounter = STARTING_AT_ONE; argsCounter < NUMBER_OF_ARGS;
	    argsCounter++)
	{
		int matchedInputs = sscanf(argv[argsCounter],"%lf %c",
		                           &receivedValue, &dummyValue);
		if(matchedInputs != NUMBERS_ONLY)
		{
			errorValue = INTEGERS_ONLY;
		}
		else
		{
			double cardsNumberDouble = atof(argv[FIRST_ARG]);
			double playersNumberDouble = atof(argv[SECOND_ARG]);
			int cardsNumber = (int)cardsNumberDouble;
			int playersNumber = (int)playersNumberDouble;
			if((cardsNumberDouble != cardsNumber) ||
			   (playersNumberDouble != playersNumber))
			{
				errorValue = INTEGERS_ONLY;
			}
		}
	}
	return errorValue;
}


